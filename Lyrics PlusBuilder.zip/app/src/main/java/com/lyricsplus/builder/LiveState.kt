package com.lyricsplus.builder

/** Status penghubung live yang dibaca layar (diisi oleh LiveService). */
object LiveState {
    @Volatile var running = false
    @Volatile var minecraftConnected = false
    @Volatile var permissionOk = false
    @Volatile var title = ""
    @Volatile var artist = ""
    @Volatile var playing = false
    @Volatile var positionSec = 0.0
    @Volatile var lyricStatus = ""
    @Volatile var lyricLines = 0
    @Volatile var sent = 0
    @Volatile var error = ""
    @Volatile var panelShown = false
}
