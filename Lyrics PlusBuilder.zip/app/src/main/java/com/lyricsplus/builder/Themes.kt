package com.lyricsplus.builder

import android.graphics.Color

/** Pilihan tema warna aplikasi. */
object Themes {
    class T(
        val name: String, val accent: Int, val accentLight: Int, val chipBg: Int,
        val bg: Int, val card: Int, val input: Int, val navBg: Int, val navSel: Int, val plate: Int
    )

    private fun c(s: String) = Color.parseColor(s)

    val list = listOf(
        T("Ungu", c("#7C5CFF"), c("#C9BEFF"), c("#26204D"), c("#0F0F14"), c("#1B1B24"), c("#12121A"), c("#14141C"), c("#1E1A3A"), c("#5B3FD9")),
        T("Pink", c("#FF5FA2"), c("#FFC4DD"), c("#4A1D35"), c("#150D12"), c("#241720"), c("#1A0F16"), c("#1B1017"), c("#3A1829"), c("#E0457F")),
        T("Biru", c("#3D8BFF"), c("#BBD6FF"), c("#1B2C4D"), c("#0C1118"), c("#16202C"), c("#0F1620"), c("#111A26"), c("#16284A"), c("#2468D6")),
        T("Hijau", c("#2ED47A"), c("#B9F5D3"), c("#173D2B"), c("#0B1410"), c("#15221B"), c("#0E1812"), c("#101C16"), c("#14301F"), c("#1FA861")),
        T("Oranye", c("#FF9A3D"), c("#FFD9B0"), c("#4A2D12"), c("#14100B"), c("#241C14"), c("#19130D"), c("#1A140E"), c("#3A2410"), c("#E07A1A")),
        T("Merah", c("#FF4D5E"), c("#FFC0C6"), c("#4A1A20"), c("#140C0D"), c("#241517"), c("#190E10"), c("#1A0F11"), c("#3A1519"), c("#D93445"))
    )

    fun get(idx: Int): T = list[idx.coerceIn(0, list.size - 1)]
}
