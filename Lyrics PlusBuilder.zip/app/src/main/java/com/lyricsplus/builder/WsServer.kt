package com.lyricsplus.builder

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.net.BindException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import kotlin.concurrent.thread

/**
 * Server WebSocket mini (tanpa library) yang hanya menerima sambungan dari HP ini sendiri (127.0.0.1).
 * Minecraft Bedrock tersambung ke sini lewat perintah /connect 127.0.0.1:PORT.
 */
class WsServer(private val port: Int) {
    @Volatile var running = false
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var client: Socket? = null
    private val lock = Any()
    private val sender = java.util.concurrent.Executors.newSingleThreadExecutor()

    var onConnected: () -> Unit = {}
    var onDisconnected: () -> Unit = {}
    var onError: (String) -> Unit = {}

    val connected: Boolean get() = client != null

    fun start() {
        running = true
        thread(isDaemon = true, name = "lp-ws-accept") {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port))
                serverSocket = ss
                while (running) {
                    val s = ss.accept()
                    thread(isDaemon = true, name = "lp-ws-client") { handle(s) }
                }
            } catch (e: BindException) {
                if (running) onError("Port $port sedang dipakai app lain. Tutup pendamping lain yang memakai port ini.")
            } catch (e: Exception) {
                if (running) onError(e.message ?: "Server error")
            }
        }
    }

    fun stop() {
        running = false
        try { sender.shutdown() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        synchronized(lock) {
            try { client?.close() } catch (_: Exception) {}
            client = null
        }
    }

    /**
     * Kirim satu pesan teks ke Minecraft. Penulisan ke socket dilakukan di thread terpisah
     * (Android melarang akses jaringan di thread utama). Hasil false kalau belum tersambung.
     */
    fun sendText(text: String): Boolean {
        if (!running) return false
        val s = client ?: return false
        val data = frame(0x1, text.toByteArray(Charsets.UTF_8))
        try {
            sender.execute {
                try {
                    synchronized(lock) {
                        val os = s.getOutputStream()
                        os.write(data)
                        os.flush()
                    }
                } catch (e: Exception) {
                    try { s.close() } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            return false
        }
        return true
    }

    private fun handle(s: Socket) {
        try {
            s.tcpNoDelay = true
            s.soTimeout = 5000
            val ins = s.getInputStream()
            val head = readHeaders(ins)
            if (head == null) {
                s.close()
                return
            }
            val key = Regex("(?im)^Sec-WebSocket-Key:\\s*(.+?)\\s*\$").find(head)?.groupValues?.get(1)
            if (key == null) {
                s.close()
                return
            }
            val resp = "HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                "Sec-WebSocket-Accept: " + acceptKey(key) + "\r\n\r\n"
            val os = s.getOutputStream()
            os.write(resp.toByteArray(Charsets.ISO_8859_1))
            os.flush()
            s.soTimeout = 0

            synchronized(lock) {
                val old = client
                client = s
                try { old?.close() } catch (_: Exception) {}
            }
            onConnected()

            while (running) {
                val f = readFrame(ins) ?: break
                if (f.first == 0x8) break
                if (f.first == 0x9) {
                    val pong = frame(0xA, f.second)
                    synchronized(lock) {
                        os.write(pong)
                        os.flush()
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            var was = false
            synchronized(lock) {
                if (client === s) {
                    client = null
                    was = true
                }
            }
            try { s.close() } catch (_: Exception) {}
            if (was) onDisconnected()
        }
    }

    private fun acceptKey(key: String): String {
        val md = MessageDigest.getInstance("SHA-1")
        val digest = md.digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray(Charsets.ISO_8859_1))
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }

    private fun readHeaders(ins: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 16384) {
            val b = ins.read()
            if (b < 0) return null
            sb.append(b.toChar())
            if (sb.length >= 4 && sb.endsWith("\r\n\r\n")) return sb.toString()
        }
        return null
    }

    private fun readByte(ins: InputStream): Int {
        val b = ins.read()
        if (b < 0) throw EOFException()
        return b
    }

    private fun readFully(ins: InputStream, buf: ByteArray) {
        var n = 0
        while (n < buf.size) {
            val r = ins.read(buf, n, buf.size - n)
            if (r < 0) throw EOFException()
            n += r
        }
    }

    /** Baca satu frame WebSocket. Hasil: (opcode, isi). Null kalau sambungan putus atau frame terlalu besar. */
    private fun readFrame(ins: InputStream): Pair<Int, ByteArray>? {
        val b0 = ins.read()
        if (b0 < 0) return null
        val b1 = readByte(ins)
        val opcode = b0 and 0x0F
        val masked = (b1 and 0x80) != 0
        var len = (b1 and 0x7F).toLong()
        if (len == 126L) {
            len = ((readByte(ins) shl 8) or readByte(ins)).toLong()
        } else if (len == 127L) {
            var l = 0L
            for (i in 0 until 8) l = (l shl 8) or readByte(ins).toLong()
            len = l
        }
        if (len > 4_000_000L) return null
        val mask = ByteArray(4)
        if (masked) readFully(ins, mask)
        val payload = ByteArray(len.toInt())
        readFully(ins, payload)
        if (masked) {
            for (i in payload.indices) payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
        }
        return Pair(opcode, payload)
    }

    private fun frame(opcode: Int, payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0x80 or opcode)
        val len = payload.size
        if (len < 126) {
            out.write(len)
        } else if (len < 65536) {
            out.write(126)
            out.write(len shr 8)
            out.write(len and 0xFF)
        } else {
            out.write(127)
            for (i in 7 downTo 0) out.write(((len.toLong() shr (8 * i)) and 0xFFL).toInt())
        }
        out.write(payload)
        return out.toByteArray()
    }
}
