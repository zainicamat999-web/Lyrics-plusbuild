package com.lyricsplus.builder

import android.service.notification.NotificationListenerService

/**
 * Sengaja kosong. Layanan ini cuma dibutuhkan supaya Android mau memberi APK akses ke sesi media
 * (lagu yang sedang diputar di Spotify, YouTube Music, dan app musik lain).
 */
class MediaListener : NotificationListenerService()
