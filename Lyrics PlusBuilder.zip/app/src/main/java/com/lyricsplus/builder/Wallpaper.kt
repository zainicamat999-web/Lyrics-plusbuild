package com.lyricsplus.builder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** Wallpaper aplikasi: foto dari galeri diperkecil lalu disimpan di penyimpanan app. */
object Wallpaper {
    fun file(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    fun exists(ctx: Context) = file(ctx).exists()

    fun clear(ctx: Context) {
        file(ctx).delete()
    }

    fun load(ctx: Context): Bitmap? {
        if (!exists(ctx)) return null
        return try {
            BitmapFactory.decodeFile(file(ctx).absolutePath)
        } catch (e: Throwable) {
            null
        }
    }

    private fun rotation(ctx: Context, uri: Uri): Int {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                when (ExifInterface(ins).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val maxSide = Math.max(bounds.outWidth, bounds.outHeight)
            if (maxSide <= 0) return false
            var sample = 1
            while (maxSide / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val deg = rotation(ctx, uri)
            if (deg != 0) {
                val m = Matrix()
                m.postRotate(deg.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(file(ctx)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}
