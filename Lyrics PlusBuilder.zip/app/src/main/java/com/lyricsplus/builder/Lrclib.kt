package com.lyricsplus.builder

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/** Ambil lirik berwaktu (format LRC) dari LRCLIB. */
object Lrclib {
    private const val UA = "LyricsPlusBuilder/2.0"

    class Found(val synced: String, val title: String, val artist: String, val duration: Double)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun getJson(url: String): Any? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", UA)
        try {
            val code = c.responseCode
            if (code == 404) return null
            if (code != 200) throw IOException("Server lirik membalas kode $code")
            val text = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return JSONTokener(text).nextValue()
        } finally {
            c.disconnect()
        }
    }

    private fun synced(o: JSONObject): String? {
        if (o.isNull("syncedLyrics")) return null
        val s = o.optString("syncedLyrics", "")
        return if (s.isBlank()) null else s
    }

    private fun toFound(o: JSONObject, s: String) =
        Found(s, o.optString("trackName", ""), o.optString("artistName", ""), o.optDouble("duration", 0.0))

    /** Semua versi lirik berwaktu yang cocok, yang durasinya paling dekat di urutan atas. */
    fun findAll(title: String, artist: String, durationSec: Int): List<Found> {
        val out = ArrayList<Found>()

        var q = "track_name=${enc(title)}"
        if (artist.isNotBlank()) q += "&artist_name=${enc(artist)}"
        if (durationSec > 0) q += "&duration=$durationSec"
        val exact = getJson("https://lrclib.net/api/get?$q")
        if (exact is JSONObject) {
            val s = synced(exact)
            if (s != null) out.add(toFound(exact, s))
        }

        val arr = getJson("https://lrclib.net/api/search?q=${enc("$artist $title".trim())}") as? JSONArray
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val s = synced(o) ?: continue
                if (out.none { it.synced == s }) out.add(toFound(o, s))
            }
        }

        val sorted = if (durationSec > 0) out.sortedBy { abs(it.duration - durationSec) } else out
        return sorted.take(10)
    }
}
