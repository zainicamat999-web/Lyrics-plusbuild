package com.lyricsplus.builder

/** Baca, geser, potong, dan susun teks LRC ([mm:ss.xx] baris lirik). */
object LrcShift {
    private val TS = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?\\]")
    private val TAG = Regex("^\\[[A-Za-z]+:.*\\]$")

    class Line(var t: Double, val text: String)

    fun fmtTs(t: Double): String {
        val total = Math.round(Math.max(0.0, t) * 100).toInt()
        return "[%02d:%02d.%02d]".format(total / 6000, (total / 100) % 60, total % 100)
    }

    fun build(lines: List<Line>): String = lines.joinToString("\n") { fmtTs(it.t) + " " + it.text }

    /** deltaSec > 0: lirik muncul lebih lambat. deltaSec < 0: lirik muncul lebih awal. */
    fun shift(lrc: String, deltaSec: Double): String {
        val delta = Math.round(deltaSec * 100).toInt()
        return TS.replace(lrc) { m ->
            val min = m.groupValues[1].toInt()
            val sec = m.groupValues[2].toInt()
            val frac = m.groupValues[3]
            val cs = when (frac.length) {
                0 -> 0
                1 -> frac.toInt() * 10
                2 -> frac.toInt()
                else -> Math.round(frac.toInt() / Math.pow(10.0, (frac.length - 2).toDouble())).toInt()
            }
            var total = (min * 60 + sec) * 100 + cs + delta
            if (total < 0) total = 0
            "[%02d:%02d.%02d]".format(total / 6000, (total / 100) % 60, total % 100)
        }
    }

    /** Baca LRC jadi daftar baris berwaktu, urut dari waktu terkecil. */
    fun parse(lrc: String): List<Line> {
        val out = ArrayList<Line>()
        for (raw in lrc.lines()) {
            val ms = TS.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val text = TS.replace(raw, "").trim()
            for (m in ms) {
                val frac = m.groupValues[3]
                val f = if (frac.isEmpty()) 0.0 else frac.toInt() / Math.pow(10.0, frac.length.toDouble())
                out.add(Line(m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt() + f, text))
            }
        }
        out.sortBy { it.t }
        return out
    }

    /** Potong lirik ke rentang [startSec, endSec) lalu geser supaya mulai dari 0. endSec <= 0 berarti sampai akhir. */
    fun trim(lrc: String, startSec: Double, endSec: Double): String {
        val kept = parse(lrc).filter { it.t >= startSec - 0.001 && (endSec <= 0.0 || it.t < endSec) }
        return build(kept.map { Line(it.t - startSec, it.text) })
    }

    /** Baris lirik biasa tanpa timestamp (untuk ketuk-sinkron). */
    fun plainLines(text: String): List<String> =
        text.lines().map { TS.replace(it, "").trim() }.filter { it.isNotEmpty() && !TAG.matches(it) }

    /** Titik awal kasar: bagi rata semua baris di sepanjang lagu. Bukan sinkron otomatis. */
    fun spread(plain: List<String>, startSec: Double, endSec: Double): String {
        if (plain.isEmpty()) return ""
        val step = (endSec - startSec) / plain.size
        val lines = ArrayList<Line>()
        for ((i, s) in plain.withIndex()) lines.add(Line(startSec + i * step, s))
        return build(lines)
    }
}
