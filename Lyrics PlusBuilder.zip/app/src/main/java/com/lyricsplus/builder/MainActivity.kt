package com.lyricsplus.builder

import android.app.Activity
import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private var BG = Color.parseColor("#0F0F14")
    private var CARD = Color.parseColor("#1B1B24")
    private var CARD_SOLID = Color.parseColor("#1B1B24")
    private var INPUT = Color.parseColor("#12121A")
    private var ACCENT = Color.parseColor("#7C5CFF")
    private var ACCENT_LIGHT = Color.parseColor("#C9BEFF")
    private var CHIP_BG = Color.parseColor("#26204D")
    private var NAV_BG = Color.parseColor("#14141C")
    private var NAV_SEL = Color.parseColor("#1E1A3A")
    private var PLATE = Color.parseColor("#5B3FD9")
    private val MUTED = Color.parseColor("#9A9AAE")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val fontNames = arrayOf("Sans", "Serif", "Mono", "Tebal miring")
    private val fontFaces = arrayOf(
        Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD),
        Typeface.create(Typeface.SERIF, Typeface.BOLD),
        Typeface.create(Typeface.MONOSPACE, Typeface.BOLD),
        Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
    )
    private val colorNames = arrayOf("Putih", "Kuning", "Cyan", "Pink")
    private val colorValues = intArrayOf(
        Color.WHITE, Color.parseColor("#FFD54F"), Color.parseColor("#4DD0E1"), Color.parseColor("#FF80AB")
    )

    private class QItem(
        val audio: Uri, val title: String, val artist: String, val lrc: String, val eco: Boolean,
        val trimStart: Double, val trimEnd: Double, val fadeIn: Double, val fadeOut: Double
    )

    private lateinit var prefs: Prefs

    companion object {
        private val queue = ArrayList<QItem>()
    }

    private var addonUri: Uri? = null
    private var audioUri: Uri? = null
    private var audioSec = 0
    private var outUri: Uri? = null
    private var outName = ""
    private var shiftTotal = 0.0
    private var busy = false
    private var currentPage = 0

    private var player: MediaPlayer? = null
    private var seeking = false
    private var parsedText = ""
    private var parsed: List<LrcShift.Line> = emptyList()
    private var editLines: MutableList<LrcShift.Line> = ArrayList()
    private val handler = Handler(Looper.getMainLooper())
    private val tick: Runnable = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!seeking) seek.progress = p.currentPosition
            refreshPreview()
            if (p.isPlaying) handler.postDelayed(this, 100)
        }
    }

    // halaman dan navigasi
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()
    private lateinit var pageHost: FrameLayout
    private lateinit var splash: View
    private lateinit var wallpaperView: ImageView
    private lateinit var dimView: View
    private lateinit var wallStatus: TextView
    private lateinit var wallDimTv: TextView
    private lateinit var splashPlate: View
    private lateinit var splashT1: View
    private lateinit var splashT2: View
    private lateinit var splashFill: View

    // halaman Buat
    private lateinit var addonStatus: TextView
    private lateinit var audioStatus: TextView
    private lateinit var lyricStatus: TextView
    private lateinit var buildStatus: TextView
    private lateinit var titleEt: EditText
    private lateinit var artistEt: EditText
    private lateinit var lrcEt: EditText
    private lateinit var ecoCb: CheckBox
    private lateinit var queueBox: LinearLayout
    private lateinit var bar: ProgressBar
    private lateinit var buildBtn: Button
    private lateinit var openBtn: Button
    private lateinit var shareBtn: Button

    // halaman Editor
    private lateinit var playBtn: Button
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var prevTv: TextView
    private lateinit var curTv: TextView
    private lateinit var nextTv: TextView
    private lateinit var styledTv: TextView
    private lateinit var fontBtn: Button
    private lateinit var colorBtn: Button
    private lateinit var shiftLabel: TextView
    private lateinit var trimStartEt: EditText
    private lateinit var trimEndEt: EditText
    private lateinit var fadeInEt: EditText
    private lateinit var fadeOutEt: EditText
    private lateinit var trimInfo: TextView
    private lateinit var lineBox: LinearLayout

    // halaman Lagu
    private lateinit var libStatus: TextView
    private lateinit var libBox: LinearLayout
    private lateinit var histBox: LinearLayout

    // halaman Live
    private lateinit var liveAccessTv: TextView
    private lateinit var liveBtn: Button
    private lateinit var liveServerTv: TextView
    private lateinit var liveMcTv: TextView
    private lateinit var liveTrackTv: TextView
    private lateinit var liveLyricTv: TextView
    private lateinit var liveErrTv: TextView
    private lateinit var livePanelPermTv: TextView
    private lateinit var livePanelBtn: Button
    private val liveTick: Runnable = object : Runnable {
        override fun run() {
            refreshLive()
            handler.postDelayed(this, 1000)
        }
    }

    // halaman Setelan
    private lateinit var offsetLabel: TextView
    private lateinit var useResultCb: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        initTheme()
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        applyWallpaper()
        restoreSource()
        applyStyle()
        restoreFormState(savedInstanceState)
        showPage(savedInstanceState?.getInt("page", 0) ?: 0)
        if (savedInstanceState == null) playSplash() else splash.visibility = View.GONE
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", currentPage)
        outState.putString("audio", audioUri?.toString() ?: "")
        outState.putInt("audioSec", audioSec)
        outState.putString("title", titleEt.text.toString())
        outState.putString("artist", artistEt.text.toString())
        outState.putString("lrc", lrcEt.text.toString())
        outState.putString("ts", trimStartEt.text.toString())
        outState.putString("te", trimEndEt.text.toString())
        outState.putString("fi", fadeInEt.text.toString())
        outState.putString("fo", fadeOutEt.text.toString())
    }

    private fun restoreFormState(b: Bundle?) {
        if (b == null) return
        val au = b.getString("audio", "") ?: ""
        if (au.isNotEmpty()) {
            val u = Uri.parse(au)
            audioUri = u
            audioSec = b.getInt("audioSec", 0)
            audioStatus.text = "Dipilih: " + nameOf(u)
        }
        titleEt.setText(b.getString("title", ""))
        artistEt.setText(b.getString("artist", ""))
        lrcEt.setText(b.getString("lrc", ""))
        trimStartEt.setText(b.getString("ts", ""))
        trimEndEt.setText(b.getString("te", ""))
        fadeInEt.setText(b.getString("fi", ""))
        fadeOutEt.setText(b.getString("fo", ""))
        updateTrimInfo()
        refreshEditorLines()
        renderQueue()
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun initTheme() {
        val t = Themes.get(prefs.themeIdx)
        BG = t.bg
        CARD = withAlpha(t.card, 0xE0)
        CARD_SOLID = t.card
        INPUT = withAlpha(t.input, 0xEE)
        ACCENT = t.accent
        ACCENT_LIGHT = t.accentLight
        CHIP_BG = t.chipBg
        NAV_BG = withAlpha(t.navBg, 0xF2)
        NAV_SEL = t.navSel
        PLATE = t.plate
    }

    private fun applyWallpaper() {
        val bmp = Wallpaper.load(this)
        if (bmp == null) {
            wallpaperView.visibility = View.GONE
            dimView.visibility = View.GONE
            return
        }
        wallpaperView.setImageBitmap(bmp)
        wallpaperView.visibility = View.VISIBLE
        dimView.visibility = View.VISIBLE
        dimView.alpha = prefs.wallpaperDim / 100f
    }

    private fun updateWallStatus() {
        wallStatus.text = if (Wallpaper.exists(this)) "Wallpaper aktif" else "Belum ada wallpaper"
    }

    // ---------- Bantuan tampilan ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private enum class Kind { PRIMARY, SECONDARY, SUCCESS }

    private fun button(t: String, kind: Kind = Kind.SECONDARY, compact: Boolean = false, onClick: () -> Unit) =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = if (compact) 12f else 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            val h = if (compact) 38 else 48
            minHeight = dp(h)
            minimumHeight = dp(h)
            setPadding(dp(if (compact) 8 else 14), 0, dp(if (compact) 8 else 14), 0)
            stateListAnimator = null
            val fill = when (kind) {
                Kind.PRIMARY -> ACCENT
                Kind.SUCCESS -> Color.parseColor("#2E9E5B")
                Kind.SECONDARY -> Color.parseColor("#2A2A38")
            }
            val shape = rounded(fill, 12)
            if (kind == Kind.SECONDARY) shape.setStroke(dp(1), Color.parseColor("#3D3D52"))
            background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), shape, null)
            setOnClickListener { onClick() }
        }

    private fun edit(hintText: String, multiline: Boolean = false, numeric: Boolean = false) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.parseColor("#666677"))
        setTextColor(Color.WHITE)
        background = rounded(INPUT, 10)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        minHeight = dp(48)
        if (multiline) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 8
            gravity = Gravity.TOP
        } else if (numeric) {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine()
        } else {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
    }

    private fun card(root: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = rounded(CARD, 16)
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(12)
        root.addView(c, lp)
        c.addView(label(title, 16f, Color.WHITE, true))
        return c
    }

    private fun gap(parent: LinearLayout, h: Int = 8) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    /** Dua tampilan berdampingan dengan lebar sama. */
    private fun pairRow(a: View, b: View): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val la = LinearLayout.LayoutParams(0, WRAP, 1f)
        la.rightMargin = dp(8)
        row.addView(a, la)
        row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    private fun newPage(): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(20))
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            addView(col)
        }
        pageHost.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        pages.add(sv)
        return col
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun status(m: String) = runOnUiThread { buildStatus.text = m }

    private fun num(et: EditText): Double = et.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0

    private fun fmt(ms: Int) = "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)

    private fun fmtSize(b: Long): String =
        if (b >= 1024L * 1024L) "%.1f MB".format(Locale.US, b / 1048576.0) else "${b / 1024} KB"

    private fun nameOf(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "file"
        }
        return "file"
    }

    private fun canOpen(u: Uri): Boolean {
        return try {
            val s = contentResolver.openInputStream(u)
            s?.close()
            s != null
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Susunan layar ----------
    private fun buildUi() {
        val rootFrame = FrameLayout(this).apply { setBackgroundColor(BG) }
        wallpaperView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }
        dimView = View(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        rootFrame.addView(wallpaperView, FrameLayout.LayoutParams(MATCH, MATCH))
        rootFrame.addView(dimView, FrameLayout.LayoutParams(MATCH, MATCH))
        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pageHost = FrameLayout(this)
        main.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
        main.addView(buildNav(), LinearLayout.LayoutParams(MATCH, WRAP))
        rootFrame.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        buildCreatePage()
        buildEditorPage()
        buildLibraryPage()
        buildLivePage()
        buildSettingsPage()

        splash = buildSplash()
        rootFrame.addView(splash, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(rootFrame)
    }

    private fun buildNav(): LinearLayout {
        val navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(NAV_BG)
        }
        val names = listOf("Buat", "Editor", "Lagu", "Live", "Setelan")
        for ((i, n) in names.withIndex()) {
            val t = label(n, 13f, MUTED, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { showPage(i) }
            }
            navItems.add(t)
            navBar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return navBar
    }

    private fun showPage(idx: Int) {
        currentPage = idx
        for ((i, p) in pages.withIndex()) p.visibility = if (i == idx) View.VISIBLE else View.GONE
        for ((i, t) in navItems.withIndex()) {
            val on = i == idx
            t.setTextColor(if (on) ACCENT_LIGHT else MUTED)
            t.setBackgroundColor(if (on) NAV_SEL else Color.TRANSPARENT)
        }
        if (idx == 1) {
            refreshEditorLines()
            updateTrimInfo()
        }
        if (idx == 2) {
            loadLibrary()
            renderHistory()
        }
        if (idx == 3) refreshLive()
    }

    // ---------- Halaman 1: Buat ----------
    private fun buildCreatePage() {
        val root = newPage()

        val chip = label("Lyrics by Zaini", 12f, ACCENT_LIGHT, true).apply {
            letterSpacing = 0.05f
            background = rounded(CHIP_BG, 20)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        root.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP))
        gap(root, 12)
        root.addView(label("LyricsPlus Builder", 24f, Color.WHITE, true))
        root.addView(label("Tambah lagu + lirik ke add-on LyricsPlus lu. Lirik dicari online, hasilnya dipakai offline di Minecraft.", 13f, MUTED))
        gap(root, 16)

        // 1. Add-on sumber
        val c1 = card(root, "1. Add-on sumber (LyricsPlus)")
        addonStatus = label("Belum dipilih (file .mcaddon)", 13f, MUTED)
        gap(c1)
        c1.addView(button("Pilih file .mcaddon") { pick(1, "*/*") })
        gap(c1)
        c1.addView(addonStatus)

        // 2. Lagu
        val c2 = card(root, "2. Lagu (file audio di HP lu)")
        audioStatus = label("Belum dipilih (mp3, m4a, ogg, wav...)", 13f, MUTED)
        gap(c2)
        c2.addView(button("Pilih file lagu") { pick(2, "audio/*") })
        gap(c2)
        c2.addView(audioStatus)
        gap(c2)
        titleEt = edit("Judul lagu")
        c2.addView(titleEt)
        gap(c2)
        artistEt = edit("Artis")
        c2.addView(artistEt)
        gap(c2)
        ecoCb = CheckBox(this).apply {
            text = "Hemat ukuran (mono 22 kHz, file jauh lebih kecil)"
            setTextColor(Color.WHITE)
            textSize = 13f
        }
        c2.addView(ecoCb)

        // 3. Lirik
        val c3 = card(root, "3. Lirik berwaktu")
        gap(c3)
        c3.addView(button("Cari lirik online") { searchLyrics() })
        gap(c3)
        lyricStatus = label("Atau tempel lirik format LRC sendiri di bawah.", 13f, MUTED)
        c3.addView(lyricStatus)
        gap(c3)
        lrcEt = edit("[00:12.50] baris lirik pertama\n[00:16.00] baris kedua", multiline = true)
        c3.addView(lrcEt)
        gap(c3)
        c3.addView(label("Lirik belum ada waktunya? Tempel lirik biasa, lalu:", 12f, MUTED))
        gap(c3, 6)
        c3.addView(pairRow(
            button("Ketuk-sinkron") { openTapSync() },
            button("Bagi rata") { spreadLyrics() }
        ))
        gap(c3, 6)
        c3.addView(label("Bagi rata cuma titik awal kasar. Rapikan di halaman Editor.", 12f, MUTED))

        // 4. Antrean
        val c4 = card(root, "4. Antrean lagu (opsional)")
        c4.addView(label("Isi satu lagu, tekan Tambah, lalu isi lagu berikutnya. Semua masuk ke satu add-on.", 12f, MUTED))
        gap(c4)
        c4.addView(button("Tambah ke antrean") { addToQueue() })
        gap(c4)
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c4.addView(queueBox)
        renderQueue()

        // 5. Bangun
        val c5 = card(root, "5. Bangun add-on")
        gap(c5)
        buildBtn = button("Bangun add-on", Kind.PRIMARY) { build() }
        c5.addView(buildBtn)
        gap(c5)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        c5.addView(bar)
        buildStatus = label("", 13f, MUTED)
        c5.addView(buildStatus)
        gap(c5)
        openBtn = button("Buka di Minecraft", Kind.SUCCESS) { openInMinecraft() }
        shareBtn = button("Bagikan add-on") { shareOut() }
        val rowOut = pairRow(openBtn, shareBtn)
        rowOut.visibility = View.GONE
        outRow = rowOut
        c5.addView(rowOut)
    }

    // ---------- Halaman 2: Editor ----------
    private fun buildEditorPage() {
        val root = newPage()
        root.addView(label("Editor timing", 22f, Color.WHITE, true))
        root.addView(label("Putar lagu, lihat lirik jalan, lalu atur timing sampai pas.", 13f, MUTED))
        gap(root, 12)

        // Pemutar
        val cp = card(root, "Pemutar dan pratinjau")
        gap(cp)
        playBtn = button("Putar", Kind.PRIMARY) { togglePlay() }
        cp.addView(playBtn)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) {
                    player?.seekTo(v)
                    refreshPreview()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                seeking = false
            }
        })
        cp.addView(seek)
        timeTv = label("00:00 / 00:00", 12f, MUTED)
        cp.addView(timeTv)
        gap(cp, 10)
        prevTv = label("", 13f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 }
        curTv = label("", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER; minLines = 2; maxLines = 3 }
        nextTv = label("", 13f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 }
        cp.addView(prevTv)
        cp.addView(curTv)
        cp.addView(nextTv)

        // Gaya lirik 3D (perkiraan)
        val cs = card(root, "Pratinjau gaya lirik 3D (perkiraan)")
        cs.addView(label("Kira-kira gayanya di game: kata muncul satu per satu. Font dan warna asli diatur di menu add-on.", 12f, MUTED))
        gap(cs)
        styledTv = label("", 30f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            minLines = 2
            maxLines = 3
            setPadding(dp(12), dp(24), dp(12), dp(24))
            background = rounded(Color.parseColor("#233A2B"), 12)
            setShadowLayer(6f, 3f, 3f, Color.BLACK)
        }
        cs.addView(styledTv, LinearLayout.LayoutParams(MATCH, WRAP))
        gap(cs)
        fontBtn = button("Font") {
            prefs.fontIdx = (prefs.fontIdx + 1) % fontNames.size
            applyStyle()
        }
        colorBtn = button("Warna") {
            prefs.colorIdx = (prefs.colorIdx + 1) % colorNames.size
            applyStyle()
        }
        cs.addView(pairRow(fontBtn, colorBtn))

        // Geser semua lirik
        val cg = card(root, "Geser semua lirik")
        cg.addView(label("Lambat = lirik muncul lebih telat. Lebih awal = lirik muncul lebih cepat.", 12f, MUTED))
        shiftLabel = label("Sudah digeser: 0.0 dtk", 12f, MUTED)
        cg.addView(shiftLabel)
        gap(cg)
        cg.addView(shiftRow("Lebih awal 1" to -1.0, "Lambat 1" to 1.0))
        gap(cg)
        cg.addView(shiftRow("Lebih awal 0.5" to -0.5, "Lambat 0.5" to 0.5))
        gap(cg)
        cg.addView(shiftRow("Lebih awal 0.1" to -0.1, "Lambat 0.1" to 0.1))

        // Potong dan fade
        val ct = card(root, "Potong lagu dan fade")
        ct.addView(label("Pakai bagian tertentu saja (misal cuma reff). Liriknya ikut dipotong otomatis.", 12f, MUTED))
        gap(ct)
        trimStartEt = edit("Mulai (dtk)", numeric = true)
        trimEndEt = edit("Selesai (dtk)", numeric = true)
        ct.addView(pairRow(trimStartEt, trimEndEt))
        gap(ct)
        ct.addView(pairRow(
            button("Mulai = posisi sekarang", Kind.SECONDARY, true) {
                trimStartEt.setText(String.format(Locale.US, "%.1f", positionSec()))
            },
            button("Selesai = posisi sekarang", Kind.SECONDARY, true) {
                trimEndEt.setText(String.format(Locale.US, "%.1f", positionSec()))
            }
        ))
        gap(ct)
        fadeInEt = edit("Fade in (dtk)", numeric = true)
        fadeOutEt = edit("Fade out (dtk)", numeric = true)
        ct.addView(pairRow(fadeInEt, fadeOutEt))
        gap(ct)
        trimInfo = label("", 12f, MUTED)
        ct.addView(trimInfo)
        gap(ct)
        ct.addView(button("Reset potong dan fade", Kind.SECONDARY, true) {
            trimStartEt.setText("")
            trimEndEt.setText("")
            fadeInEt.setText("")
            fadeOutEt.setText("")
        })
        val w = Watch { updateTrimInfo() }
        trimStartEt.addTextChangedListener(w)
        trimEndEt.addTextChangedListener(w)
        fadeInEt.addTextChangedListener(w)
        fadeOutEt.addTextChangedListener(w)

        // Editor per baris
        val cl = card(root, "Timing per baris")
        cl.addView(label("Ketuk baris untuk lompat ke bagian itu di lagu. Tombol di bawahnya menggeser baris itu saja.", 12f, MUTED))
        gap(cl)
        cl.addView(button("Segarkan daftar baris", Kind.SECONDARY, true) { refreshEditorLines() })
        gap(cl)
        lineBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cl.addView(lineBox)
    }

    // ---------- Halaman 3: Lagu ----------
    private fun buildLibraryPage() {
        val root = newPage()
        root.addView(label("Lagu di add-on", 22f, Color.WHITE, true))
        root.addView(label("Lihat isi add-on sumber dan hapus lagu yang nggak dipakai.", 13f, MUTED))
        gap(root, 12)

        val c1 = card(root, "Isi add-on sumber")
        libStatus = label("", 13f, MUTED)
        gap(c1)
        c1.addView(button("Muat ulang daftar", Kind.SECONDARY, true) { loadLibrary() })
        gap(c1)
        c1.addView(libStatus)
        gap(c1)
        libBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c1.addView(libBox)

        val c2 = card(root, "Riwayat build")
        c2.addView(label("Pilih Pakai untuk balik ke versi lama sebagai sumber berikutnya.", 12f, MUTED))
        gap(c2)
        histBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c2.addView(histBox)
    }

    // ---------- Halaman 4: Setelan ----------
    private fun buildSettingsPage() {
        val root = newPage()
        root.addView(label("Setelan", 22f, Color.WHITE, true))
        gap(root, 12)

        val ct = card(root, "Tema warna")
        ct.addView(label("Warna tombol, label, dan loading screen. Mengganti tema memuat ulang layar.", 12f, MUTED))
        gap(ct)
        var i = 0
        while (i < Themes.list.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in i until Math.min(i + 3, Themes.list.size)) {
                val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
                if (j < i + 2) lp.rightMargin = dp(6)
                row.addView(themeButton(j), lp)
            }
            ct.addView(row)
            gap(ct, 6)
            i += 3
        }

        val cw = card(root, "Wallpaper")
        cw.addView(label("Foto dari galeri jadi latar belakang aplikasi. Kartu dibuat agak transparan.", 12f, MUTED))
        gap(cw)
        wallStatus = label("", 13f, Color.WHITE, true)
        cw.addView(wallStatus)
        gap(cw)
        cw.addView(pairRow(
            button("Pilih foto") { pick(3, "image/*") },
            button("Hapus wallpaper") {
                Wallpaper.clear(this)
                applyWallpaper()
                updateWallStatus()
            }
        ))
        gap(cw)
        wallDimTv = label("", 12f, Color.WHITE)
        cw.addView(wallDimTv)
        val dim = SeekBar(this)
        dim.max = 90
        dim.progress = prefs.wallpaperDim
        dim.progressTintList = ColorStateList.valueOf(ACCENT)
        dim.thumbTintList = ColorStateList.valueOf(ACCENT)
        wallDimTv.text = "Gelapkan wallpaper: " + dim.progress + "%"
        dim.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                wallDimTv.text = "Gelapkan wallpaper: " + v + "%"
                prefs.wallpaperDim = v
                dimView.alpha = v / 100f
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        cw.addView(dim)
        updateWallStatus()

        val c1 = card(root, "Koreksi game")
        c1.addView(label("Kalau di Minecraft liriknya selalu meleset sedikit, isi selisihnya di sini. Otomatis ditambahkan ke semua lagu saat bangun (nggak ngaruh ke pratinjau).", 12f, MUTED))
        gap(c1)
        offsetLabel = label("", 16f, Color.WHITE, true)
        c1.addView(offsetLabel)
        gap(c1)
        c1.addView(pairRow(
            button("Lebih awal 0.1") { adjustOffset(-0.1f) },
            button("Lambat 0.1") { adjustOffset(0.1f) }
        ))
        gap(c1)
        c1.addView(pairRow(
            button("Lebih awal 0.5") { adjustOffset(-0.5f) },
            button("Lambat 0.5") { adjustOffset(0.5f) }
        ))
        gap(c1)
        c1.addView(button("Reset ke 0") {
            prefs.gameOffset = 0f
            updateOffsetLabel()
        })
        updateOffsetLabel()

        val c2 = card(root, "Add-on sumber")
        useResultCb = CheckBox(this).apply {
            text = "Setelah bangun, pakai hasilnya sebagai add-on sumber berikutnya"
            setTextColor(Color.WHITE)
            textSize = 13f
            isChecked = prefs.useResultAsSource
            setOnCheckedChangeListener { _, checked -> prefs.useResultAsSource = checked }
        }
        c2.addView(useResultCb)

        val c3 = card(root, "Tentang")
        c3.addView(label("Lyrics by Zaini", 15f, ACCENT_LIGHT, true))
        c3.addView(label("LyricsPlus Builder 2.0. Untuk Minecraft Bedrock.", 12f, MUTED))
    }

    // ---------- Halaman Live ----------
    private fun buildLivePage() {
        val root = newPage()
        root.addView(label("Live dari app musik", 22f, Color.WHITE, true))
        root.addView(label("Putar lagu di app musik (Spotify, YouTube Music, dll), liriknya tampil di Minecraft lewat add-on LyricsPlus. Butuh internet buat cari lirik.", 13f, MUTED))
        gap(root, 12)

        val c1 = card(root, "1. Izinkan akses ke app musik")
        c1.addView(label("APK perlu akses notifikasi supaya bisa membaca lagu yang sedang diputar. Nggak perlu login Spotify.", 12f, MUTED))
        gap(c1)
        liveAccessTv = label("", 13f, Color.WHITE, true)
        c1.addView(liveAccessTv)
        gap(c1)
        c1.addView(button("Buka pengaturan akses notifikasi") { openNotifSettings() })
        gap(c1)
        c1.addView(label("Android 13 ke atas: kalau pilihannya abu-abu, buka Info aplikasi, ketuk titik tiga di pojok kanan atas, pilih Izinkan setelan terbatas, lalu ulangi langkah di atas.", 12f, MUTED))
        gap(c1)
        c1.addView(button("Buka info aplikasi", Kind.SECONDARY, true) { openAppInfo() })

        val c2 = card(root, "2. Nyalakan penghubung")
        c2.addView(label("Penghubung jalan di latar belakang (ada notifikasi tetap) supaya tetap hidup waktu lu main Minecraft.", 12f, MUTED))
        gap(c2)
        liveBtn = button("Mulai penghubung", Kind.PRIMARY) { toggleLive() }
        c2.addView(liveBtn)
        gap(c2)
        liveServerTv = label("", 13f, Color.WHITE)
        c2.addView(liveServerTv)
        liveMcTv = label("", 13f, Color.WHITE)
        c2.addView(liveMcTv)

        val c3 = card(root, "3. Sambungkan Minecraft")
        c3.addView(label("a. Masuk ke dunia yang cheat-nya aktif (wajib buat perintah /connect).", 13f, Color.WHITE))
        gap(c3, 4)
        c3.addView(label("b. Di Minecraft: Settings, General, matikan Require Encrypted Websockets.", 13f, Color.WHITE))
        gap(c3, 4)
        c3.addView(label("c. Ketik di chat: /connect 127.0.0.1:" + LiveService.PORT, 13f, Color.WHITE))
        gap(c3, 4)
        c3.addView(label("d. Buka menu add-on (jongkok 3x), aktifkan opsi Spotify.", 13f, Color.WHITE))
        gap(c3)
        c3.addView(button("Salin perintah /connect") { copyConnect() })

        val c5 = card(root, "4. Panel melayang (atur gaya lirik)")
        c5.addView(label("Panel kecil yang muncul di atas Minecraft untuk ganti font, tata letak, animasi, warna, dan ukuran lirik tanpa keluar dari game. Butuh add-on LyricsPlus v2.1 dan penghubung yang sudah tersambung.", 12f, MUTED))
        gap(c5)
        livePanelPermTv = label("", 13f, Color.WHITE, true)
        c5.addView(livePanelPermTv)
        gap(c5)
        c5.addView(button("Izinkan tampil di atas aplikasi lain") { openOverlaySettings() })
        gap(c5)
        livePanelBtn = button("Tampilkan panel melayang", Kind.PRIMARY) { togglePanel() }
        c5.addView(livePanelBtn)

        val c4 = card(root, "Sedang diputar")
        liveTrackTv = label("", 13f, Color.WHITE, true)
        c4.addView(liveTrackTv)
        gap(c4, 4)
        liveLyricTv = label("", 12f, MUTED)
        c4.addView(liveLyricTv)
        gap(c4, 4)
        liveErrTv = label("", 12f, Color.parseColor("#FF8A80"))
        c4.addView(liveErrTv)
    }

    private fun notifAccessEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    private fun refreshLive() {
        val ok = notifAccessEnabled()
        liveAccessTv.text = if (ok) "Akses notifikasi: AKTIF" else "Akses notifikasi: belum diizinkan"
        liveAccessTv.setTextColor(if (ok) Color.parseColor("#6FE3A0") else Color.parseColor("#FF8A80"))
        liveBtn.text = if (LiveState.running) "Hentikan penghubung" else "Mulai penghubung"
        liveServerTv.text = if (LiveState.running) "Server aktif di 127.0.0.1:" + LiveService.PORT else "Server mati"
        liveMcTv.text = if (LiveState.minecraftConnected) "Minecraft: tersambung" else "Minecraft: belum tersambung"
        if (LiveState.title.isEmpty()) {
            liveTrackTv.text = "Belum ada lagu terbaca."
        } else {
            liveTrackTv.text = (if (LiveState.playing) "Memutar: " else "Jeda: ") + LiveState.artist + " - " +
                LiveState.title + " (" + fmt((LiveState.positionSec * 1000).toInt()) + ")"
        }
        liveLyricTv.text = if (LiveState.lyricStatus.isEmpty()) "" else
            "Lirik: " + LiveState.lyricStatus + ". Terkirim ke game: " + LiveState.sent + " perintah."
        liveErrTv.text = LiveState.error
        val canDraw = Settings.canDrawOverlays(this)
        livePanelPermTv.text = if (canDraw) "Izin tampil di atas aplikasi lain: AKTIF" else "Izin tampil di atas aplikasi lain: belum diizinkan"
        livePanelPermTv.setTextColor(if (canDraw) Color.parseColor("#6FE3A0") else Color.parseColor("#FF8A80"))
        livePanelBtn.text = if (LiveState.panelShown) "Sembunyikan panel melayang" else "Tampilkan panel melayang"
    }

    private fun toggleLive() {
        if (LiveState.running) {
            startService(Intent(this, LiveService::class.java).setAction(LiveService.ACTION_STOP))
            return
        }
        if (!notifAccessEnabled()) toast("Aktifkan akses notifikasi dulu (langkah 1)")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        startForegroundService(Intent(this, LiveService::class.java))
    }

    private fun openNotifSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            toast("Buka manual: Pengaturan, Notifikasi, Akses notifikasi")
        }
    }

    private fun openAppInfo() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + packageName)))
        } catch (e: Exception) {
            toast("Buka manual: Pengaturan, Aplikasi, LyricsPlus Builder")
        }
    }

    private fun copyConnect() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("connect", "/connect 127.0.0.1:" + LiveService.PORT))
        toast("Disalin. Tempel di chat Minecraft.")
    }

    private fun togglePanel() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan 'Tampil di atas aplikasi lain' dulu")
            openOverlaySettings()
            return
        }
        val act = if (LiveState.panelShown) LiveService.ACTION_HIDE_PANEL else LiveService.ACTION_SHOW_PANEL
        startForegroundService(Intent(this, LiveService::class.java).setAction(act))
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        } catch (e: Exception) {
            toast("Buka manual: Pengaturan, Aplikasi, Akses khusus, Tampil di atas aplikasi lain")
        }
    }

    private fun themeButton(j: Int): View {
        val t = Themes.list[j]
        return Button(this).apply {
            text = t.name
            isAllCaps = false
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            minHeight = dp(44)
            minimumHeight = dp(44)
            stateListAnimator = null
            val shape = rounded(t.accent, 12)
            if (j == prefs.themeIdx) shape.setStroke(dp(3), Color.WHITE)
            background = shape
            setOnClickListener {
                if (prefs.themeIdx != j) {
                    prefs.themeIdx = j
                    recreate()
                }
            }
        }
    }

    private fun adjustOffset(d: Float) {
        prefs.gameOffset = Math.round((prefs.gameOffset + d) * 10) / 10f
        updateOffsetLabel()
    }

    private fun updateOffsetLabel() {
        offsetLabel.text = "Koreksi game: " + String.format(Locale.US, "%+.1f", prefs.gameOffset) + " dtk"
    }

    // ---------- Layar pembuka ----------
    private fun buildSplash(): View {
        val box = FrameLayout(this).apply {
            setBackgroundColor(BG)
            isClickable = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val plate = FrameLayout(this).apply {
            background = rounded(PLATE, 28)
            alpha = 0f
            scaleX = 0.5f
            scaleY = 0.5f
        }
        val icon = ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) }
        plate.addView(icon, FrameLayout.LayoutParams(dp(112), dp(112)))
        col.addView(plate, LinearLayout.LayoutParams(dp(112), dp(112)))
        gap(col, 24)

        val t1 = label("Lyrics by Zaini", 26f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
            alpha = 0f
            translationY = dp(14).toFloat()
        }
        val t2 = label("LyricsPlus Builder", 13f, MUTED).apply {
            gravity = Gravity.CENTER
            alpha = 0f
        }
        col.addView(t1, LinearLayout.LayoutParams(WRAP, WRAP))
        gap(col, 4)
        col.addView(t2, LinearLayout.LayoutParams(WRAP, WRAP))
        gap(col, 28)

        val track = FrameLayout(this).apply { background = rounded(Color.parseColor("#1E1E2A"), 3) }
        val fill = View(this).apply {
            background = rounded(ACCENT, 3)
            pivotX = 0f
            scaleX = 0f
        }
        track.addView(fill, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(track, LinearLayout.LayoutParams(dp(160), dp(4)))
        box.addView(col, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        splashPlate = plate
        splashT1 = t1
        splashT2 = t2
        splashFill = fill
        return box
    }

    private fun playSplash() {
        splashPlate.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
            .setInterpolator(OvershootInterpolator(1.6f)).start()
        splashT1.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(450).start()
        splashT2.animate().alpha(1f).setStartDelay(600).setDuration(450).start()
        splashFill.animate().scaleX(1f).setStartDelay(300).setDuration(1500).start()
        handler.postDelayed({
            splash.animate().alpha(0f).setDuration(350).withEndAction { splash.visibility = View.GONE }.start()
        }, 2100L)
    }

    private lateinit var outRow: View

    // ---------- Sumber add-on ----------
    private fun setSource(u: Uri, name: String) {
        addonUri = u
        prefs.sourceUri = u.toString()
        addonStatus.text = "Sumber: $name"
    }

    private fun restoreSource() {
        val su = prefs.sourceUri
        if (su.isEmpty()) return
        val u = Uri.parse(su)
        if (canOpen(u)) {
            addonUri = u
            addonStatus.text = "Sumber: " + nameOf(u) + " (diingat dari terakhir)"
        } else {
            prefs.sourceUri = ""
        }
    }

    private fun applyStyle() {
        val f = prefs.fontIdx % fontFaces.size
        val c = prefs.colorIdx % colorValues.size
        styledTv.typeface = fontFaces[f]
        styledTv.setTextColor(colorValues[c])
        fontBtn.text = "Font: " + fontNames[f]
        colorBtn.text = "Warna: " + colorNames[c]
    }

    // ---------- Pilih file ----------
    private fun pick(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, code)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val u = data?.data ?: return
        when (requestCode) {
            1 -> {
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                setSource(u, nameOf(u))
            }
            2 -> {
                releasePlayer()
                audioUri = u
                val fileName = nameOf(u)
                audioStatus.text = "Dipilih: $fileName"
                var t: String? = null
                var a: String? = null
                var ms = 0L
                val mr = MediaMetadataRetriever()
                try {
                    mr.setDataSource(this, u)
                    t = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    a = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    try { mr.release() } catch (_: Exception) {}
                }
                audioSec = (ms / 1000).toInt()
                titleEt.setText(if (!t.isNullOrBlank()) t else fileName.substringBeforeLast('.'))
                if (!a.isNullOrBlank()) artistEt.setText(a)
                updateTrimInfo()
            }
            3 -> {
                val ok = Wallpaper.save(this, u)
                toast(if (ok) "Wallpaper dipasang" else "Gagal memakai foto ini")
                applyWallpaper()
                updateWallStatus()
            }
        }
    }

    // ---------- Cari lirik ----------
    private fun searchLyrics() {
        val t = titleEt.text.toString().trim()
        val a = artistEt.text.toString().trim()
        if (t.isEmpty()) {
            toast("Isi judul lagu dulu")
            return
        }
        lyricStatus.text = "Mencari lirik..."
        thread {
            try {
                val res = Lrclib.findAll(t, a, audioSec)
                runOnUiThread {
                    if (res.isEmpty()) {
                        lyricStatus.text = "Lirik berwaktu nggak ketemu. Coba ubah judul/artis, tempel LRC manual, atau pakai Ketuk-sinkron."
                    } else if (res.size == 1) {
                        applyFound(res[0])
                    } else {
                        chooseLyric(res)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { lyricStatus.text = "Gagal cari lirik: ${e.message}" }
            }
        }
    }

    private fun chooseLyric(res: List<Lrclib.Found>) {
        lyricStatus.text = "Ketemu ${res.size} versi, pilih salah satu."
        val items = res.map { f -> f.artist + " - " + f.title + " (" + fmt((f.duration * 1000).toInt()) + ")" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih versi lirik")
            .setItems(items) { _, which -> applyFound(res[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun applyFound(f: Lrclib.Found) {
        lrcEt.setText(f.synced)
        shiftTotal = 0.0
        shiftLabel.text = "Sudah digeser: 0.0 dtk"
        lyricStatus.text = "Dipakai: ${f.artist} - ${f.title}"
        refreshPreview()
        refreshEditorLines()
    }

    private fun spreadLyrics() {
        val plain = LrcShift.plainLines(lrcEt.text.toString())
        if (plain.isEmpty()) {
            toast("Tempel lirik biasa dulu di kotak lirik")
            return
        }
        if (audioSec <= 0) {
            toast("Pilih file lagu dulu supaya durasinya diketahui")
            return
        }
        val start = num(trimStartEt)
        val end = if (num(trimEndEt) > 0.0) num(trimEndEt) else audioSec.toDouble()
        lrcEt.setText(LrcShift.spread(plain, start, end))
        lyricStatus.text = "Dibagi rata. Rapikan di halaman Editor."
        refreshPreview()
        refreshEditorLines()
    }

    // ---------- Ketuk-sinkron ----------
    private fun openTapSync() {
        val plain = LrcShift.plainLines(lrcEt.text.toString())
        if (plain.isEmpty()) {
            toast("Tempel lirik biasa dulu di kotak lirik")
            return
        }
        val p = ensurePlayer() ?: return
        val times = DoubleArray(plain.size)
        var idx = 0
        var dlg: AlertDialog? = null

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(CARD_SOLID)
        }
        box.addView(label("Ketuk-sinkron", 18f, Color.WHITE, true))
        box.addView(label("Putar lagu, lalu ketuk tombol besar tepat saat baris di bawah mulai dinyanyikan. Waktu ketukan otomatis dikurangi 0.15 dtk.", 12f, MUTED))
        gap(box, 12)
        val pv = label("", 13f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 }
        val cv = label("", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER; minLines = 2; maxLines = 3 }
        val nv = label("", 13f, MUTED).apply { gravity = Gravity.CENTER; maxLines = 2 }
        val info = label("", 12f, MUTED).apply { gravity = Gravity.CENTER }
        box.addView(pv)
        box.addView(cv)
        box.addView(nv)
        gap(box, 4)
        box.addView(info)
        gap(box, 12)

        fun render() {
            pv.text = if (idx > 0) plain[idx - 1] else ""
            cv.text = if (idx < plain.size) plain[idx] else "Semua baris sudah diketuk. Tekan Selesai."
            nv.text = if (idx + 1 < plain.size) plain[idx + 1] else ""
            info.text = "Baris " + Math.min(idx + 1, plain.size) + "/" + plain.size
        }
        render()

        box.addView(button("Putar / Jeda") { togglePlay() })
        gap(box, 8)
        val tapB = button("KETUK", Kind.PRIMARY) {
            if (!p.isPlaying) {
                toast("Putar lagunya dulu")
            } else if (idx < plain.size) {
                times[idx] = Math.max(0.0, p.currentPosition / 1000.0 - 0.15)
                idx++
                render()
            }
        }
        tapB.minHeight = dp(80)
        tapB.minimumHeight = dp(80)
        tapB.textSize = 20f
        box.addView(tapB)
        gap(box, 8)
        box.addView(pairRow(
            button("Undo") {
                idx = Math.max(0, idx - 1)
                render()
            },
            button("Selesai", Kind.SUCCESS) {
                val lines = ArrayList<LrcShift.Line>()
                for (i in 0 until idx) lines.add(LrcShift.Line(times[i], plain[i]))
                var t = if (idx > 0) times[idx - 1] else 0.0
                for (i in idx until plain.size) {
                    t += 4.0
                    lines.add(LrcShift.Line(t, plain[i]))
                }
                lrcEt.setText(LrcShift.build(lines))
                if (p.isPlaying) {
                    p.pause()
                    handler.removeCallbacks(tick)
                    playBtn.text = "Putar"
                }
                lyricStatus.text = if (idx < plain.size) "Ketuk-sinkron selesai (baris sisanya diberi waktu kasar)." else "Ketuk-sinkron selesai."
                refreshPreview()
                refreshEditorLines()
                dlg?.dismiss()
            }
        ))
        gap(box, 8)
        box.addView(button("Batal") { dlg?.dismiss() })

        val d = AlertDialog.Builder(this).setView(box).create()
        dlg = d
        d.show()
    }

    // ---------- Antrean ----------
    private fun currentItem(): QItem? {
        val au = audioUri ?: return null
        val lrc = lrcEt.text.toString()
        if (lrc.isBlank()) return null
        return QItem(
            au, titleEt.text.toString().trim(), artistEt.text.toString().trim(), lrc, ecoCb.isChecked,
            num(trimStartEt), num(trimEndEt), num(fadeInEt), num(fadeOutEt)
        )
    }

    private fun addToQueue() {
        if (audioUri == null) {
            toast("Pilih file lagu dulu")
            return
        }
        val item = currentItem()
        if (item == null) {
            toast("Lirik masih kosong")
            return
        }
        if (LrcShift.parse(item.lrc).isEmpty()) {
            toast("Lirik harus berformat LRC, contoh: [00:12.50] baris lirik")
            return
        }
        queue.add(item)
        renderQueue()
        resetForm()
        toast("Masuk antrean. Isi lagu berikutnya.")
    }

    private fun renderQueue() {
        queueBox.removeAllViews()
        if (queue.isEmpty()) {
            queueBox.addView(label("Antrean kosong.", 12f, MUTED))
            return
        }
        queueBox.addView(label("${queue.size} lagu di antrean:", 12f, MUTED))
        for ((i, q) in queue.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val name = (i + 1).toString() + ". " + q.title.ifBlank { "Lagu baru" } + " - " + q.artist.ifBlank { "Belum diisi" }
            row.addView(label(name, 13f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(button("Hapus", Kind.SECONDARY, true) {
                queue.removeAt(i)
                renderQueue()
            })
            queueBox.addView(row)
        }
    }

    private fun resetForm() {
        releasePlayer()
        audioUri = null
        audioSec = 0
        audioStatus.text = "Belum dipilih (mp3, m4a, ogg, wav...)"
        titleEt.setText("")
        artistEt.setText("")
        lrcEt.setText("")
        trimStartEt.setText("")
        trimEndEt.setText("")
        fadeInEt.setText("")
        fadeOutEt.setText("")
        lyricStatus.text = "Atau tempel lirik format LRC sendiri di bawah."
        shiftTotal = 0.0
        shiftLabel.text = "Sudah digeser: 0.0 dtk"
        refreshEditorLines()
        updateTrimInfo()
    }

    // ---------- Bangun ----------
    private fun build() {
        if (busy) {
            toast("Tunggu proses sebelumnya selesai")
            return
        }
        val ad = addonUri
        if (ad == null) {
            toast("Pilih add-on sumber dulu")
            return
        }
        val items = ArrayList<QItem>(queue)
        val cur = currentItem()
        if (cur != null) items.add(cur)
        if (items.isEmpty()) {
            toast(if (audioUri != null) "Lirik masih kosong" else "Pilih lagu dulu")
            return
        }
        busy = true
        buildBtn.isEnabled = false
        outRow.visibility = View.GONE
        bar.progress = 0
        status("Mulai...")
        thread {
            val tmp = ArrayList<File>()
            try {
                val songs = ArrayList<AddonBuilder.NewSong>()
                val total = items.size
                for ((k, item) in items.withIndex()) {
                    status("Mengubah lagu ${k + 1}/$total ke WAV...")
                    val wav = File(cacheDir, "song_$k.wav")
                    tmp.add(wav)
                    val r = AudioConverter.toWav(
                        this, item.audio, wav, item.eco,
                        item.trimStart, item.trimEnd, item.fadeIn, item.fadeOut
                    ) { pct -> runOnUiThread { bar.progress = ((k * 100 + pct) * 85 / 100) / total } }
                    val lrc = if (item.trimStart > 0.0 || item.trimEnd > 0.0) {
                        LrcShift.trim(item.lrc, item.trimStart, item.trimEnd)
                    } else {
                        item.lrc
                    }
                    songs.add(AddonBuilder.NewSong(wav, item.title, item.artist, lrc, r.durationSec))
                }
                status("Menyusun add-on...")
                val res = AddonBuilder.build(this, ad, songs, prefs.gameOffset.toDouble(), prefs.minPatch)
                runOnUiThread { bar.progress = 95 }
                val uri = saveToDownloads(res.file, res.fileName)
                res.file.delete()
                prefs.minPatch = res.newPatch + 1
                val titles = items.joinToString(", ") { it.title.ifBlank { "Lagu baru" } }
                prefs.addHistory(Prefs.Hist(res.fileName, uri.toString(), System.currentTimeMillis(), "+" + songs.size + " lagu: " + titles))
                runOnUiThread {
                    outUri = uri
                    outName = res.fileName
                    bar.progress = 100
                    buildStatus.text = "Selesai! ${songs.size} lagu masuk ke Download/${res.fileName}" +
                        (if (res.notes.isEmpty()) "" else "\n" + res.notes.joinToString("\n"))
                    outRow.visibility = View.VISIBLE
                    if (prefs.useResultAsSource) setSource(uri, res.fileName)
                    queue.clear()
                    renderQueue()
                    resetForm()
                    buildBtn.isEnabled = true
                    busy = false
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    buildStatus.text = "Gagal: ${e.message ?: e.javaClass.simpleName}"
                    buildBtn.isEnabled = true
                    busy = false
                }
            } finally {
                for (f in tmp) f.delete()
            }
        }
    }

    private fun saveToDownloads(f: File, name: String): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            ?: throw java.io.IOException("Gagal membuat file di folder Download")
        contentResolver.openOutputStream(uri)!!.use { os -> f.inputStream().use { it.copyTo(os) } }
        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return uri
    }

    private fun openUri(u: Uri) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(u, "application/octet-stream")
            setPackage("com.mojang.minecraftpe")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Buka manual dari app Files: folder Download")
        }
    }

    private fun openInMinecraft() {
        val u = outUri ?: return
        openUri(u)
    }

    private fun shareOut() {
        val u = outUri ?: return
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, "Bagikan add-on"))
    }

    // ---------- Pemutar dan pratinjau ----------
    private fun positionSec(): Double {
        val p = player ?: return 0.0
        return p.currentPosition / 1000.0
    }

    private fun showLyric(sec: Double) {
        val cur = lrcEt.text.toString()
        if (cur != parsedText) {
            parsedText = cur
            parsed = LrcShift.parse(cur)
        }
        val ls = parsed
        if (ls.isEmpty()) {
            prevTv.text = ""
            curTv.text = "(lirik kosong atau bukan format LRC)"
            nextTv.text = ""
            styledTv.text = ""
            return
        }
        var idx = -1
        for (i in ls.indices) {
            if (ls[i].t <= sec) idx = i else break
        }
        fun txt(i: Int): String = if (i in ls.indices) ls[i].text.ifBlank { "..." } else ""
        prevTv.text = txt(idx - 1)
        curTv.text = if (idx < 0) "..." else txt(idx)
        nextTv.text = txt(idx + 1)
        val span = if (idx >= 0 && idx + 1 < ls.size) ls[idx + 1].t - ls[idx].t else 4.0
        styledTv.text = if (idx < 0) "" else reveal(txt(idx), sec - ls[idx].t, span)
    }

    private fun reveal(text: String, elapsed: Double, span: Double): CharSequence {
        val window = Math.min(Math.max(span, 0.5), 3.0)
        val frac = Math.min(1.0, Math.max(0.0, elapsed / window))
        val words = Regex("\\S+").findAll(text).toList()
        if (words.isEmpty()) return text
        val shown = Math.max(1, Math.ceil(frac * words.size).toInt())
        val sb = SpannableStringBuilder(text)
        for ((i, w) in words.withIndex()) {
            if (i >= shown) {
                sb.setSpan(ForegroundColorSpan(Color.TRANSPARENT), w.range.first, w.range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return sb
    }

    private fun refreshPreview() {
        val p = player
        if (p == null) {
            showLyric(0.0)
            return
        }
        val pos = p.currentPosition
        timeTv.text = fmt(pos) + " / " + fmt(p.duration)
        showLyric(pos / 1000.0)
    }

    private fun ensurePlayer(): MediaPlayer? {
        player?.let { return it }
        val u = audioUri ?: run {
            toast("Pilih file lagu dulu")
            return null
        }
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, u)
            mp.prepare()
            mp.setOnCompletionListener {
                handler.removeCallbacks(tick)
                playBtn.text = "Putar"
                refreshPreview()
            }
            player = mp
            seek.max = mp.duration
            mp
        } catch (e: Exception) {
            toast("Gagal memutar lagu: ${e.message}")
            null
        }
    }

    private fun togglePlay() {
        val p = ensurePlayer() ?: return
        if (p.isPlaying) {
            p.pause()
            handler.removeCallbacks(tick)
            playBtn.text = "Putar"
            refreshPreview()
        } else {
            if (p.currentPosition >= p.duration - 200) p.seekTo(0)
            p.start()
            playBtn.text = "Jeda"
            handler.post(tick)
        }
    }

    private fun seekAndPlay(sec: Double) {
        val p = ensurePlayer() ?: return
        p.seekTo(Math.max(0, (sec * 1000).toInt()))
        if (!p.isPlaying) {
            p.start()
            playBtn.text = "Jeda"
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun releasePlayer() {
        handler.removeCallbacks(tick)
        try { player?.release() } catch (_: Exception) {}
        player = null
        playBtn.text = "Putar"
        seek.progress = 0
        timeTv.text = "00:00 / 00:00"
        prevTv.text = ""
        curTv.text = ""
        nextTv.text = ""
        styledTv.text = ""
    }

    override fun onResume() {
        super.onResume()
        handler.post(liveTick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(liveTick)
        val p = player
        if (p != null && p.isPlaying) {
            p.pause()
            handler.removeCallbacks(tick)
            playBtn.text = "Putar"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(liveTick)
        try { player?.release() } catch (_: Exception) {}
        player = null
        super.onDestroy()
    }

    // ---------- Geser timing ----------
    private fun shiftRow(a: Pair<String, Double>, b: Pair<String, Double>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, p) in listOf(a, b).withIndex()) {
            val btn = button(p.first) { shiftLyrics(p.second) }
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i == 0) lp.rightMargin = dp(8)
            row.addView(btn, lp)
        }
        return row
    }

    private fun shiftLyrics(d: Double) {
        val cur = lrcEt.text.toString()
        if (cur.isBlank()) {
            toast("Lirik masih kosong")
            return
        }
        lrcEt.setText(LrcShift.shift(cur, d))
        shiftTotal += d
        val sign = if (shiftTotal > 0.001) "+" else ""
        shiftLabel.text = "Sudah digeser: " + sign + "%.1f".format(Locale.US, shiftTotal) + " dtk"
        refreshPreview()
        refreshEditorLines()
    }

    private fun updateTrimInfo() {
        if (audioSec <= 0) {
            trimInfo.text = "Pilih file lagu dulu."
            return
        }
        val s = num(trimStartEt)
        val eRaw = num(trimEndEt)
        val e = if (eRaw > 0.0) Math.min(eRaw, audioSec.toDouble()) else audioSec.toDouble()
        val len = e - s
        trimInfo.text = if (len <= 0.0) {
            "Rentang tidak valid: mulai harus lebih kecil dari selesai."
        } else {
            "Hasil: " + fmt((len * 1000).toInt()) + " dari " + fmt(audioSec * 1000)
        }
    }

    // ---------- Editor per baris ----------
    private fun refreshEditorLines() {
        lineBox.removeAllViews()
        val ls = LrcShift.parse(lrcEt.text.toString())
        if (ls.isEmpty()) {
            lineBox.addView(label("Belum ada lirik berwaktu. Isi dulu di halaman Buat.", 13f, MUTED))
            return
        }
        editLines = ls.toMutableList()
        for (i in editLines.indices) lineBox.addView(lineRow(i))
    }

    private fun lineRow(i: Int): View {
        val ln = editLines[i]
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(10))
        }
        val head = label(LrcShift.fmtTs(ln.t) + " " + ln.text, 13f, Color.WHITE).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(INPUT, 10)
        }
        head.setOnClickListener { seekAndPlay(ln.t - 0.5) }
        row.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        gap(row, 6)
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val steps = doubleArrayOf(-0.5, -0.1, 0.1, 0.5)
        val names = arrayOf("-0.5", "-0.1", "+0.1", "+0.5")
        for (k in steps.indices) {
            val d = steps[k]
            val btn = button(names[k], Kind.SECONDARY, true) { shiftLine(i, d, head) }
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (k < steps.size - 1) lp.rightMargin = dp(6)
            btns.addView(btn, lp)
        }
        row.addView(btns)
        return row
    }

    private fun shiftLine(i: Int, d: Double, head: TextView) {
        val ln = editLines[i]
        ln.t = Math.max(0.0, ln.t + d)
        head.text = LrcShift.fmtTs(ln.t) + " " + ln.text
        lrcEt.setText(LrcShift.build(editLines))
        refreshPreview()
    }

    // ---------- Lagu di add-on ----------
    private fun loadLibrary() {
        val ad = addonUri
        if (ad == null) {
            libBox.removeAllViews()
            libStatus.text = "Pilih add-on sumber dulu di halaman Buat."
            return
        }
        libStatus.text = "Membaca isi add-on..."
        thread {
            try {
                val items = Library.list(this, ad)
                runOnUiThread { renderLibrary(items) }
            } catch (e: Throwable) {
                runOnUiThread { libStatus.text = "Gagal membaca: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    private fun renderLibrary(items: List<Library.SongInfo>) {
        libBox.removeAllViews()
        libStatus.text = "${items.size} lagu di add-on. Lagu bawaan (.ogg) dilindungi, yang bisa dihapus cuma lagu hasil APK ini (.wav)."
        for (info in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(INPUT, 12)
            }
            row.addView(label(info.title.ifBlank { info.id }, 14f, Color.WHITE, true))
            val sub = info.artist + " | " + fmt(info.duration * 1000) +
                (if (info.bytes > 0L) " | " + fmtSize(info.bytes) else "") + " | " + info.id
            row.addView(label(sub, 12f, MUTED))
            if (info.deletable) {
                gap(row, 6)
                row.addView(button("Hapus", Kind.SECONDARY, true) { confirmDelete(info) })
            } else {
                row.addView(label("Lagu bawaan", 11f, Color.parseColor("#6E6E86")))
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.bottomMargin = dp(8)
            libBox.addView(row, lp)
        }
    }

    private fun confirmDelete(info: Library.SongInfo) {
        AlertDialog.Builder(this)
            .setTitle("Hapus lagu?")
            .setMessage("${info.title.ifBlank { info.id }} akan dihapus dari add-on. Hasilnya disimpan sebagai file baru di folder Download.")
            .setPositiveButton("Hapus") { _, _ -> doDelete(info) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun doDelete(info: Library.SongInfo) {
        if (busy) {
            toast("Tunggu proses sebelumnya selesai")
            return
        }
        val ad = addonUri ?: return
        busy = true
        libStatus.text = "Menghapus ${info.title}..."
        thread {
            try {
                val res = Library.delete(this, ad, setOf(info.id), prefs.minPatch)
                val uri = saveToDownloads(res.file, res.fileName)
                res.file.delete()
                prefs.minPatch = res.newPatch + 1
                prefs.addHistory(Prefs.Hist(res.fileName, uri.toString(), System.currentTimeMillis(), "Hapus: " + info.title))
                runOnUiThread {
                    setSource(uri, res.fileName)
                    busy = false
                    loadLibrary()
                    renderHistory()
                    toast("Selesai. Hasil disimpan: Download/" + res.fileName)
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    libStatus.text = "Gagal menghapus: ${e.message ?: e.javaClass.simpleName}"
                    busy = false
                }
            }
        }
    }

    // ---------- Riwayat build ----------
    private fun renderHistory() {
        histBox.removeAllViews()
        val hs = prefs.history()
        if (hs.isEmpty()) {
            histBox.addView(label("Belum ada riwayat.", 13f, MUTED))
            return
        }
        val df = SimpleDateFormat("dd MMM HH:mm", Locale("id"))
        for (h in hs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(INPUT, 12)
            }
            row.addView(label(h.name, 14f, Color.WHITE, true))
            row.addView(label(df.format(Date(h.time)) + " | " + h.note, 12f, MUTED))
            gap(row, 6)
            row.addView(pairRow(
                button("Pakai", Kind.SECONDARY, true) { useHistory(h) },
                button("Buka di Minecraft", Kind.SECONDARY, true) { openUri(Uri.parse(h.uri)) }
            ))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.bottomMargin = dp(8)
            histBox.addView(row, lp)
        }
    }

    private fun useHistory(h: Prefs.Hist) {
        val u = Uri.parse(h.uri)
        if (!canOpen(u)) {
            toast("File sudah tidak ada. Catatan dihapus.")
            prefs.removeHistory(h.uri)
            renderHistory()
            return
        }
        setSource(u, h.name)
        toast("Sumber diganti ke ${h.name}")
        loadLibrary()
    }
}

private class Watch(val f: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

    override fun afterTextChanged(s: android.text.Editable?) {
        f()
    }
}
