package com.lyricsplus.builder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONObject
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Penghubung live: baca lagu yang sedang diputar di app musik (lewat sesi media Android),
 * cari liriknya di LRCLIB, lalu kirim ke add-on LyricsPlus di Minecraft lewat WebSocket (/connect).
 * Protokol add-on: scriptevent lp:l (potongan lirik) dan lp:t (info lagu + posisi, tiap detik).
 */
class LiveService : Service() {
    companion object {
        const val ACTION_STOP = "com.lyricsplus.builder.STOP"
        const val PORT = 8974
        const val ACTION_SHOW_PANEL = "com.lyricsplus.builder.SHOW_PANEL"
        const val ACTION_HIDE_PANEL = "com.lyricsplus.builder.HIDE_PANEL"
        private const val CHANNEL = "lyricsplus_live"
        private const val NOTIF_ID = 7
    }

    private val handler = Handler(Looper.getMainLooper())
    private var server: WsServer? = null
    private val resend = AtomicBoolean(true)
    private var curId = ""
    private var lyricsReady = false
    private var chunkCmds: List<String> = emptyList()
    private var maxT = 0.0
    private var chunksFor = ""
    private var lastNotif = ""
    private var panel: FloatingPanel? = null
    private val pushPanel = AtomicBoolean(true)

    private val loop: Runnable = object : Runnable {
        override fun run() {
            try {
                pushPanelIfNeeded()
                tickOnce()
            } catch (e: Exception) {
                LiveState.error = e.message ?: e.javaClass.simpleName
            }
            if (LiveState.running) handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "LyricsPlus Live", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification("Menyiapkan..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!LiveState.running) {
            LiveState.running = true
            LiveState.error = ""
            LiveState.sent = 0
            val s = WsServer(PORT)
            s.onConnected = {
                LiveState.minecraftConnected = true
                resend.set(true)
                pushPanel.set(true)
            }
            s.onDisconnected = { LiveState.minecraftConnected = false }
            s.onError = { m -> LiveState.error = m }
            s.start()
            server = s
            handler.post(loop)
        }
        if (intent != null && intent.action == ACTION_SHOW_PANEL) showPanel()
        if (intent != null && intent.action == ACTION_HIDE_PANEL) hidePanel()
        return START_STICKY
    }

    override fun onDestroy() {
        hidePanel()
        LiveState.running = false
        LiveState.minecraftConnected = false
        handler.removeCallbacksAndMessages(null)
        server?.stop()
        server = null
        super.onDestroy()
    }

    // ---------- Notifikasi ----------
    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LiveService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("LyricsPlus Live")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(open)
            .addAction(0, "Hentikan", stop)
            .setOngoing(true)
            .build()
    }

    private fun notifyText(t: String) {
        if (t == lastNotif) return
        lastNotif = t
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(t))
    }

    // ---------- Baca lagu dari app musik ----------
    private fun pickController(): MediaController? {
        val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val comp = ComponentName(this, MediaListener::class.java)
        val list = try {
            msm.getActiveSessions(comp)
        } catch (e: SecurityException) {
            LiveState.permissionOk = false
            return null
        }
        LiveState.permissionOk = true
        val others = list.filter { it.packageName != packageName }
        return others.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: others.firstOrNull()
    }

    private fun clean(s: String) = s.replace('|', '/').replace("\r", " ").replace("\n", " ").trim()

    private fun tickOnce() {
        val ctl = pickController()
        if (ctl == null) {
            LiveState.title = ""
            LiveState.artist = ""
            LiveState.playing = false
            notifyText(if (LiveState.permissionOk) "Belum ada lagu diputar" else "Akses notifikasi belum diizinkan")
            return
        }
        val md = ctl.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        var artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        if (artist.isBlank()) artist = md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val durMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (title.isBlank()) return

        val st = ctl.playbackState
        val playing = st != null && st.state == PlaybackState.STATE_PLAYING
        var posMs = 0L
        if (st != null) {
            posMs = st.position
            if (playing) posMs += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        val posSec = Math.max(0L, posMs) / 1000.0

        LiveState.title = title
        LiveState.artist = artist
        LiveState.playing = playing
        LiveState.positionSec = posSec

        val id = Integer.toHexString((title + "|" + artist).hashCode())
        if (id != curId) newTrack(id, title, artist, durMs)
        notifyText((if (playing) "Memutar: " else "Jeda: ") + artist + " - " + title)

        if (!lyricsReady) return
        val s = server ?: return
        if (!s.connected) return

        // Kirim potongan lirik dulu (saat lagu baru atau Minecraft baru tersambung), lp:t di detik berikutnya.
        if (resend.getAndSet(false) || chunksFor != curId) {
            chunksFor = curId
            for ((i, cmd) in chunkCmds.withIndex()) handler.postDelayed({ sendCmd(cmd) }, i * 150L)
            return
        }
        val durSec = Math.max(durMs / 1000, Math.round(maxT + 10.0))
        val cmd = "scriptevent lp:t " + curId + "|" + (if (playing) "1" else "0") + "|" +
            String.format(Locale.US, "%.2f", posSec) + "|" + durSec + "|" + chunkCmds.size + "|" +
            clean(title) + "|" + clean(artist)
        sendCmd(cmd)
    }

    private fun newTrack(id: String, title: String, artist: String, durMs: Long) {
        curId = id
        lyricsReady = false
        chunkCmds = emptyList()
        maxT = 0.0
        LiveState.lyricLines = 0
        LiveState.lyricStatus = "Mencari lirik..."
        thread {
            var lines: List<LrcShift.Line> = emptyList()
            var msg = ""
            try {
                val res = Lrclib.findAll(title, artist, (durMs / 1000).toInt())
                val best = res.firstOrNull()
                if (best == null) msg = "Lirik berwaktu tidak ditemukan" else lines = LrcShift.parse(best.synced)
            } catch (e: Exception) {
                msg = "Gagal cari lirik: " + (e.message ?: "")
            }
            handler.post { if (curId == id) onLyrics(id, lines, msg) }
        }
    }

    private fun onLyrics(id: String, lines: List<LrcShift.Line>, msg: String) {
        val offset = Prefs(this).gameOffset.toDouble()
        chunkCmds = buildChunks(id, lines, offset)
        maxT = if (lines.isEmpty()) 0.0 else lines[lines.size - 1].t + offset
        LiveState.lyricLines = lines.size
        LiveState.lyricStatus = if (lines.isEmpty()) {
            if (msg.isEmpty()) "Lirik tidak ditemukan" else msg
        } else {
            "siap, " + lines.size + " baris"
        }
        lyricsReady = true
    }

    /** Potong lirik jadi beberapa perintah: scriptevent lp:l ID|nomor|jumlah|detik~teks;;detik~teks */
    private fun buildChunks(id: String, lines: List<LrcShift.Line>, offset: Double): List<String> {
        val pieces = ArrayList<String>()
        for (l in lines) {
            val text = clean(l.text).replace(";;", ";")
            if (text.isEmpty()) continue
            pieces.add(String.format(Locale.US, "%.2f", Math.max(0.0, l.t + offset)) + "~" + text)
        }
        val chunks = ArrayList<String>()
        val sb = StringBuilder()
        for (p in pieces) {
            if (sb.isNotEmpty() && sb.length + p.length + 2 > 380) {
                chunks.add(sb.toString())
                sb.setLength(0)
            }
            if (sb.isNotEmpty()) sb.append(";;")
            sb.append(p)
        }
        if (sb.isNotEmpty()) chunks.add(sb.toString())
        val n = chunks.size
        val out = ArrayList<String>()
        for ((k, c) in chunks.withIndex()) out.add("scriptevent lp:l $id|$k|$n|$c")
        return out
    }

    // ---------- Panel melayang ----------
    private fun showPanel() {
        if (!Settings.canDrawOverlays(this)) {
            LiveState.error = "Izin tampil di atas aplikasi lain belum diberikan"
            return
        }
        if (panel == null) panel = FloatingPanel(this, { kv -> sendSettings(kv) }, { server?.connected == true })
        val ok = panel?.show() ?: false
        LiveState.panelShown = ok
        if (!ok) LiveState.error = "Gagal menampilkan panel melayang"
    }

    private fun hidePanel() {
        panel?.hide()
        LiveState.panelShown = false
    }

    /** Kirim pengaturan ke add-on: scriptevent lp:s kunci=nilai;kunci=nilai */
    private fun sendSettings(kv: String): Boolean {
        val s = server
        if (s == null || !s.connected) return false
        sendCmd("scriptevent lp:s " + kv)
        return true
    }

    /** Saat Minecraft baru tersambung, kirim ulang pengaturan terakhir dari panel (kalau pernah dipakai). */
    private fun pushPanelIfNeeded() {
        val s = server ?: return
        if (!s.connected || !pushPanel.get()) return
        pushPanel.set(false)
        val prefs = Prefs(this)
        if (prefs.panelTouched) sendCmd("scriptevent lp:s hello=1;" + PanelState(prefs).allAsCommand())
    }

    // ---------- Kirim ke Minecraft ----------
    private fun commandJson(cmd: String): String {
        val header = JSONObject()
            .put("version", 1)
            .put("requestId", UUID.randomUUID().toString())
            .put("messagePurpose", "commandRequest")
            .put("messageType", "commandRequest")
        val body = JSONObject()
            .put("origin", JSONObject().put("type", "player"))
            .put("commandLine", cmd)
            .put("version", 1)
        return JSONObject().put("body", body).put("header", header).toString()
    }

    private fun sendCmd(cmd: String) {
        val s = server ?: return
        if (s.sendText(commandJson(cmd))) LiveState.sent++
    }
}
