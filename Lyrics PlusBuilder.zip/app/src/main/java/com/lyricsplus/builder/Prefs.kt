package com.lyricsplus.builder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Penyimpanan kecil di HP: sumber add-on terakhir, koreksi game, riwayat build, gaya pratinjau. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lyricsplus_builder", Context.MODE_PRIVATE)

    class Hist(val name: String, val uri: String, val time: Long, val note: String)

    var sourceUri: String
        get() = sp.getString("source_uri", "") ?: ""
        set(v) {
            sp.edit().putString("source_uri", v).apply()
        }

    var gameOffset: Float
        get() = sp.getFloat("game_offset", 0f)
        set(v) {
            sp.edit().putFloat("game_offset", v).apply()
        }

    var minPatch: Int
        get() = sp.getInt("min_patch", 0)
        set(v) {
            sp.edit().putInt("min_patch", v).apply()
        }

    var useResultAsSource: Boolean
        get() = sp.getBoolean("use_result", true)
        set(v) {
            sp.edit().putBoolean("use_result", v).apply()
        }

    var fontIdx: Int
        get() = sp.getInt("font_idx", 0)
        set(v) {
            sp.edit().putInt("font_idx", v).apply()
        }

    var colorIdx: Int
        get() = sp.getInt("color_idx", 0)
        set(v) {
            sp.edit().putInt("color_idx", v).apply()
        }

    var panelJson: String
        get() = sp.getString("panel_json", "{}") ?: "{}"
        set(v) {
            sp.edit().putString("panel_json", v).apply()
        }

    var panelTouched: Boolean
        get() = sp.getBoolean("panel_touched", false)
        set(v) {
            sp.edit().putBoolean("panel_touched", v).apply()
        }

    var themeIdx: Int
        get() = sp.getInt("theme_idx", 0)
        set(v) {
            sp.edit().putInt("theme_idx", v).apply()
        }

    var wallpaperDim: Int
        get() = sp.getInt("wall_dim", 45)
        set(v) {
            sp.edit().putInt("wall_dim", v).apply()
        }

    fun history(): List<Hist> {
        val out = ArrayList<Hist>()
        try {
            val arr = JSONArray(sp.getString("history", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Hist(o.getString("name"), o.getString("uri"), o.getLong("time"), o.optString("note", "")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addHistory(h: Hist) {
        val list = ArrayList<Hist>()
        list.add(h)
        for (x in history()) if (x.uri != h.uri) list.add(x)
        saveHistory(list.take(10))
    }

    fun removeHistory(uri: String) {
        saveHistory(history().filter { it.uri != uri })
    }

    private fun saveHistory(list: List<Hist>) {
        val arr = JSONArray()
        for (h in list) {
            arr.put(JSONObject().put("name", h.name).put("uri", h.uri).put("time", h.time).put("note", h.note))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }
}
