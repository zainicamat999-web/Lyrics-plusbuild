package com.lyricsplus.builder

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale

/** Pilihan yang sama persis dengan add-on LyricsPlus v2.1. */
object PanelData {
    val fonts = listOf("Poppins", "Montserrat", "Pacifico", "Lobster", "Bebas", "Playfair", "Righteous", "Comic Relief", "Press Start", "Eagle Lake")
    val layoutIds = listOf("scatter", "rows", "wave", "stairs", "arc", "zigzag", "left", "stack")
    val layoutLabels = listOf("Sebar", "Baris", "Gelombang", "Tangga", "Lengkung", "Zig-zag", "Rata kiri", "Bertumpuk")
    val animIds = listOf("none", "fade", "pop", "both")
    val animLabels = listOf("Tanpa", "Fade", "Pop", "Fade+Pop")
    val colorModeIds = listOf("solid", "gradient", "rainbowLine", "rainbowFlow")
    val colorModeLabels = listOf("Satu warna", "Gradasi", "Pelangi baris", "Pelangi alir")
    val fogIds = listOf("off", "ungu", "pink", "senja", "malam")
    val fogLabels = listOf("Mati", "Ungu", "Pink", "Senja", "Malam")
    val paletteNames = listOf(
        "Putih", "Krem", "Kuning", "Emas", "Oranye", "Merah", "Pink", "Magenta", "Ungu",
        "Lavender", "Biru", "Biru langit", "Cyan", "Mint", "Hijau", "Lime", "Kustom"
    )
    val paletteColors = intArrayOf(
        Color.rgb(255, 255, 255), Color.rgb(255, 244, 214), Color.rgb(255, 235, 90), Color.rgb(255, 200, 60),
        Color.rgb(255, 150, 60), Color.rgb(255, 80, 80), Color.rgb(255, 150, 200), Color.rgb(255, 60, 200),
        Color.rgb(170, 100, 255), Color.rgb(200, 180, 255), Color.rgb(70, 110, 255), Color.rgb(130, 210, 255),
        Color.rgb(60, 240, 240), Color.rgb(150, 255, 200), Color.rgb(80, 220, 100), Color.rgb(190, 255, 60),
        Color.rgb(120, 120, 140)
    )

    class Preset(val name: String, vararg val kv: Pair<String, String>)

    val presets = listOf(
        Preset("Clean", "font" to "0", "layout" to "rows", "colorMode" to "solid", "color" to "0", "anim" to "fade", "size" to "1", "spread" to "20"),
        Preset("Neon", "font" to "6", "layout" to "scatter", "colorMode" to "gradient", "color" to "12", "color2" to "7", "anim" to "both", "size" to "1"),
        Preset("Karaoke", "font" to "1", "layout" to "rows", "colorMode" to "solid", "color" to "2", "anim" to "fade", "size" to "1"),
        Preset("Sunset", "font" to "2", "layout" to "scatter", "colorMode" to "gradient", "color" to "4", "color2" to "6", "anim" to "both", "size" to "1.1"),
        Preset("Retro", "font" to "8", "layout" to "rows", "colorMode" to "solid", "color" to "15", "anim" to "none", "size" to "0.9"),
        Preset("Elegan", "font" to "5", "layout" to "rows", "colorMode" to "solid", "color" to "1", "anim" to "fade", "size" to "1"),
        Preset("Poster", "font" to "4", "layout" to "scatter", "colorMode" to "solid", "color" to "0", "anim" to "pop", "size" to "1.3", "spread" to "25"),
        Preset("Lavender", "font" to "1", "layout" to "rows", "colorMode" to "solid", "color" to "16", "r" to "205", "g" to "175", "b" to "255", "anim" to "fade", "size" to "1"),
        Preset("Dreamy", "font" to "2", "layout" to "left", "colorMode" to "solid", "color" to "16", "r" to "255", "g" to "190", "b" to "225", "anim" to "both", "size" to "1"),
        Preset("Comic", "font" to "7", "layout" to "zigzag", "colorMode" to "solid", "color" to "16", "r" to "255", "g" to "225", "b" to "90", "anim" to "pop", "size" to "1"),
        Preset("Script", "font" to "3", "layout" to "arc", "colorMode" to "solid", "color" to "0", "anim" to "fade", "size" to "1"),
        Preset("Poster 2", "font" to "4", "layout" to "stack", "colorMode" to "gradient", "color" to "12", "color2" to "7", "anim" to "pop", "size" to "1.1"),
        Preset("Pelangi", "font" to "7", "layout" to "scatter", "colorMode" to "rainbowFlow", "anim" to "both", "size" to "1"),
        Preset("Gelombang", "font" to "2", "layout" to "wave", "colorMode" to "gradient", "color" to "12", "color2" to "7", "anim" to "both", "size" to "1"),
        Preset("Tangga", "font" to "6", "layout" to "stairs", "colorMode" to "gradient", "color" to "2", "color2" to "4", "anim" to "both", "size" to "1"),
        Preset("Lengkung", "font" to "1", "layout" to "arc", "colorMode" to "rainbowFlow", "anim" to "both", "size" to "1")
    )

    val defaults: Map<String, String> = mapOf(
        "font" to "0", "layout" to "scatter", "colorMode" to "solid", "color" to "0", "color2" to "11",
        "r" to "255", "g" to "255", "b" to "255", "anim" to "both", "size" to "1", "dist" to "8", "height" to "0",
        "spread" to "20", "offset" to "0", "follow" to "1", "countdown" to "1", "notes" to "0", "fog" to "off"
    )
}

/** Nilai pengaturan yang terakhir diatur lewat panel (disimpan di HP). */
class PanelState(private val prefs: Prefs) {
    val v = LinkedHashMap<String, String>()

    init {
        v.putAll(PanelData.defaults)
        try {
            val o = JSONObject(prefs.panelJson)
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                v[k] = o.getString(k)
            }
        } catch (_: Exception) {
        }
    }

    fun get(k: String): String = v[k] ?: PanelData.defaults[k] ?: ""

    fun int(k: String): Int = get(k).toDoubleOrNull()?.toInt() ?: 0

    fun num(k: String): Double = get(k).toDoubleOrNull() ?: 0.0

    fun set(k: String, value: String) {
        v[k] = value
        save()
    }

    fun save() {
        prefs.panelJson = JSONObject(v as Map<*, *>).toString()
        prefs.panelTouched = true
    }

    fun reset() {
        v.clear()
        v.putAll(PanelData.defaults)
        save()
    }

    fun allAsCommand(): String = v.entries.joinToString(";") { it.key + "=" + it.value }
}

/**
 * Panel kecil yang melayang di atas Minecraft (izin "Tampil di atas aplikasi lain").
 * Tombol bulat LP bisa digeser, ketuk untuk membuka panel pengaturan gaya lirik.
 * Perubahan dikirim ke add-on lewat send("kunci=nilai;...") -> scriptevent lp:s.
 */
class FloatingPanel(
    private val ctx: Context,
    private val send: (String) -> Boolean,
    private val connected: () -> Boolean
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = Prefs(ctx)
    private val st = PanelState(prefs)
    private var root: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var expanded = false
    private var statusTv: TextView? = null

    private val accent: Int get() = Themes.get(prefs.themeIdx).accent
    private val panelBg = Color.parseColor("#F01C1C24")
    private val chipBg = Color.parseColor("#34343F")
    private val muted = Color.parseColor("#9A9AAE")
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    val shown: Boolean get() = root != null

    private fun dp(x: Int) = (x * ctx.resources.displayMetrics.density).toInt()

    fun show(): Boolean {
        if (root != null) return true
        val r = FrameLayout(ctx)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(8)
        p.y = dp(70)
        root = r
        lp = p
        expanded = false
        fill()
        return try {
            wm.addView(r, p)
            true
        } catch (e: Exception) {
            root = null
            lp = null
            false
        }
    }

    fun hide() {
        val r = root ?: return
        try { wm.removeView(r) } catch (_: Exception) {}
        root = null
        lp = null
    }

    private fun fill() {
        val r = root ?: return
        r.removeAllViews()
        r.addView(if (expanded) buildPanel() else buildGear())
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(ctx).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun sec(t: String): TextView {
        val x = tv(t, 11f, muted, true)
        x.setPadding(0, dp(10), 0, dp(4))
        return x
    }

    /** Geser jendela dengan jari. Kalau cuma ketuk (tidak bergeser), jalankan onClick. */
    private fun attachDrag(v: View, onClick: () -> Unit) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            val p = lp
            if (p == null) {
                false
            } else {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ox = p.x
                        oy = p.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt()
                        val dy = (e.rawY - sy).toInt()
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true
                        p.x = ox + dx
                        p.y = oy + dy
                        try { wm.updateViewLayout(root, p) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) onClick()
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun buildGear(): View {
        val g = tv("LP", 14f, Color.WHITE, true)
        g.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(accent)
        g.background = bg
        g.layoutParams = FrameLayout.LayoutParams(dp(46), dp(46))
        attachDrag(g) {
            expanded = true
            fill()
        }
        return g
    }

    private fun buildPanel(): View {
        val m = ctx.resources.displayMetrics
        val w = Math.min(dp(300), (m.widthPixels * 0.62).toInt())
        val maxH = Math.min(dp(380), (m.heightPixels * 0.72).toInt())

        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(panelBg)
        bg.cornerRadius = dp(16).toFloat()
        box.background = bg
        box.setPadding(dp(12), dp(8), dp(12), dp(10))
        box.layoutParams = FrameLayout.LayoutParams(w, wrap)

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(0, dp(2), 0, dp(6))
        head.addView(tv("LyricsPlus (geser di sini)", 13f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
        val status = tv("", 11f, muted, false)
        statusTv = status
        head.addView(status)
        val close = tv("   X  ", 16f, Color.WHITE, true)
        close.setOnClickListener {
            expanded = false
            fill()
        }
        head.addView(close)
        attachDrag(head) {}
        box.addView(head)

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        buildContent(col)
        val sv = ScrollView(ctx)
        sv.addView(col)
        box.addView(sv, LinearLayout.LayoutParams(match, maxH))
        updateStatus()
        return box
    }

    private fun updateStatus() {
        val s = statusTv ?: return
        val ok = connected()
        s.text = if (ok) "tersambung" else "belum tersambung"
        s.setTextColor(if (ok) Color.parseColor("#6FE3A0") else Color.parseColor("#FF8A80"))
    }

    private fun toast(m: String) {
        try { Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
    }

    /** Simpan nilai, lalu kirim ke game kalau sudah tersambung. */
    private fun push(key: String, value: String) {
        st.set(key, value)
        val ok = send("$key=$value")
        updateStatus()
        if (!ok) toast("Minecraft belum tersambung. Pengaturan disimpan dan dikirim saat tersambung.")
    }

    private fun applyPreset(i: Int) {
        val pr = PanelData.presets[i]
        val parts = ArrayList<String>()
        for ((k, value) in pr.kv) {
            st.v[k] = value
            parts.add("$k=$value")
        }
        st.v["mode"] = "styled"
        parts.add("mode=styled")
        st.save()
        val ok = send(parts.joinToString(";"))
        if (!ok) toast("Minecraft belum tersambung. Pengaturan disimpan dan dikirim saat tersambung.")
        fill()
    }

    private fun sendAll() {
        val ok = send("hello=1;" + st.allAsCommand())
        updateStatus()
        toast(if (ok) "Semua pengaturan dikirim ke game." else "Minecraft belum tersambung.")
    }

    private fun resetAll() {
        st.reset()
        send("hello=1;" + st.allAsCommand())
        fill()
        toast("Gaya dikembalikan ke bawaan.")
    }

    private fun luminance(c: Int) = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0

    private fun styleChip(v: TextView, on: Boolean, color: Int?) {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        if (color != null) {
            bg.setColor(color)
            v.setTextColor(if (luminance(color) > 0.6) Color.BLACK else Color.WHITE)
            if (on) bg.setStroke(dp(3), Color.WHITE) else bg.setStroke(dp(1), Color.parseColor("#55000000"))
        } else {
            bg.setColor(if (on) accent else chipBg)
            v.setTextColor(Color.WHITE)
        }
        v.background = bg
    }

    private fun chips(opts: List<String>, selected: Int, colors: IntArray? = null, onPick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val views = ArrayList<TextView>()
        var sel = selected
        for ((i, name) in opts.withIndex()) {
            val c = tv(name, 12f, Color.WHITE, false)
            c.setPadding(dp(12), dp(7), dp(12), dp(7))
            views.add(c)
            val params = LinearLayout.LayoutParams(wrap, wrap)
            params.rightMargin = dp(6)
            row.addView(c, params)
            c.setOnClickListener {
                sel = i
                for ((j, x) in views.withIndex()) styleChip(x, j == sel, if (colors != null) colors[j] else null)
                onPick(i)
            }
        }
        for ((j, x) in views.withIndex()) styleChip(x, j == sel, if (colors != null) colors[j] else null)
        hs.addView(row)
        return hs
    }

    private fun slider(title: String, min: Double, max: Double, step: Double, key: String, scale: Double = 1.0, show: (Double) -> String): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val label = tv("", 12f, Color.WHITE, false)
        val bar = SeekBar(ctx)
        val steps = Math.round((max - min) / step).toInt()
        bar.max = steps
        val cur = st.num(key) * scale
        bar.progress = Math.max(0, Math.min(steps, Math.round((cur - min) / step).toInt()))
        bar.progressTintList = ColorStateList.valueOf(accent)
        bar.thumbTintList = ColorStateList.valueOf(accent)
        label.text = title + ": " + show(min + bar.progress * step)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                label.text = title + ": " + show(min + value * step)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                val value = min + bar.progress * step
                push(key, String.format(Locale.US, "%.2f", value / scale))
            }
        })
        box.addView(label)
        box.addView(bar)
        return box
    }

    private fun toggleRow(title: String, key: String): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.addView(sec(title))
        box.addView(chips(listOf("Ya", "Tidak"), if (st.get(key) == "1") 0 else 1) { i -> push(key, if (i == 0) "1" else "0") })
        return box
    }

    private fun actionBtn(t: String, onClick: () -> Unit): TextView {
        val b = tv(t, 12f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        styleChip(b, true, null)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildContent(col: LinearLayout) {
        col.addView(sec("PRESET"))
        col.addView(chips(PanelData.presets.map { it.name }, -1) { i -> applyPreset(i) })

        col.addView(sec("FONT"))
        col.addView(chips(PanelData.fonts, st.int("font")) { i -> push("font", i.toString()) })

        col.addView(sec("TATA LETAK"))
        col.addView(chips(PanelData.layoutLabels, PanelData.layoutIds.indexOf(st.get("layout"))) { i -> push("layout", PanelData.layoutIds[i]) })

        col.addView(sec("ANIMASI MASUK"))
        col.addView(chips(PanelData.animLabels, PanelData.animIds.indexOf(st.get("anim"))) { i -> push("anim", PanelData.animIds[i]) })

        col.addView(sec("MODE WARNA"))
        col.addView(chips(PanelData.colorModeLabels, PanelData.colorModeIds.indexOf(st.get("colorMode"))) { i -> push("colorMode", PanelData.colorModeIds[i]) })

        col.addView(sec("WARNA (ATAU WARNA PERTAMA GRADASI)"))
        col.addView(chips(PanelData.paletteNames, st.int("color"), PanelData.paletteColors) { i -> push("color", i.toString()) })

        col.addView(sec("WARNA KEDUA (GRADASI)"))
        col.addView(chips(PanelData.paletteNames, st.int("color2"), PanelData.paletteColors) { i -> push("color2", i.toString()) })

        col.addView(sec("WARNA KUSTOM (PILIH \"KUSTOM\" DI ATAS)"))
        col.addView(slider("Merah", 0.0, 255.0, 5.0, "r") { it.toInt().toString() })
        col.addView(slider("Hijau", 0.0, 255.0, 5.0, "g") { it.toInt().toString() })
        col.addView(slider("Biru", 0.0, 255.0, 5.0, "b") { it.toInt().toString() })

        col.addView(sec("UKURAN DAN POSISI"))
        col.addView(slider("Ukuran", 25.0, 300.0, 5.0, "size", 100.0) { it.toInt().toString() + "%" })
        col.addView(slider("Jarak", 4.0, 16.0, 1.0, "dist") { it.toInt().toString() + " blok" })
        col.addView(slider("Tinggi", -3.0, 30.0, 0.5, "height") { String.format(Locale.US, "%+.1f", it) })
        col.addView(slider("Sebaran kiri-kanan", 0.0, 40.0, 5.0, "spread") { it.toInt().toString() + " derajat" })
        col.addView(slider("Sinkron lirik (+ lebih lambat)", -5.0, 5.0, 0.1, "offset") { String.format(Locale.US, "%+.1f dtk", it) })

        col.addView(toggleRow("TEKS MENGIKUTI ARAH PANDANG", "follow"))
        col.addView(toggleRow("HITUNG MUNDUR SAAT JEDA INSTRUMENTAL", "countdown"))
        col.addView(toggleRow("EFEK NOT MUSIK SAAT BARIS BARU", "notes"))

        col.addView(sec("LANGIT DAN KABUT"))
        col.addView(chips(PanelData.fogLabels, PanelData.fogIds.indexOf(st.get("fog"))) { i -> push("fog", PanelData.fogIds[i]) })

        val actions = LinearLayout(ctx)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(0, dp(12), 0, 0)
        val l1 = LinearLayout.LayoutParams(0, wrap, 1f)
        l1.rightMargin = dp(6)
        actions.addView(actionBtn("Kirim ulang semua") { sendAll() }, l1)
        actions.addView(actionBtn("Reset gaya") { resetAll() }, LinearLayout.LayoutParams(0, wrap, 1f))
        col.addView(actions)
    }
}
