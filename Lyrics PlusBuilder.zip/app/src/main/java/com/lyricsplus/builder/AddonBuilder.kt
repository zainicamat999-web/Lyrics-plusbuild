package com.lyricsplus.builder

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Mengubah isi file .mcaddon LyricsPlus: tambah lagu, hapus lagu, naikkan versi, tulis ulang zip. */
object AddonBuilder {
    class NewSong(val wav: File, val title: String, val artist: String, val lrc: String, val durationSec: Int)

    class Out(val file: File, val fileName: String, val songIds: List<String>, val notes: List<String>, val newPatch: Int)

    private fun q(s: String) = JSONObject.quote(s)

    private fun wanted(n: String) =
        n.endsWith("scripts/songs.js") ||
            n.endsWith("scripts/main.js") ||
            n.endsWith("sounds/sound_definitions.json") ||
            (n.endsWith("manifest.json") && n.count { it == '/' } <= 1)

    /** Baca berkas penting (songs.js, main.js, sound_definitions.json, manifest) dari add-on. */
    fun readKey(ctx: Context, addon: Uri): LinkedHashMap<String, ByteArray> {
        val files = LinkedHashMap<String, ByteArray>()
        val input = ctx.contentResolver.openInputStream(addon) ?: throw IOException("Tidak bisa membuka file add-on")
        input.use { ins ->
            ZipInputStream(BufferedInputStream(ins)).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    if (!e.isDirectory && wanted(e.name)) files[e.name] = zin.readBytes()
                    e = zin.nextEntry
                }
            }
        }
        return files
    }

    private fun bump(v: JSONArray, minPatch: Int): JSONArray {
        val patch = Math.max(v.getInt(2) + 1, minPatch)
        return JSONArray().put(v.getInt(0)).put(v.getInt(1)).put(patch)
    }

    private fun isResource(j: JSONObject) =
        j.optJSONArray("modules")?.optJSONObject(0)?.optString("type") == "resources"

    /** Naikkan versi semua manifest (BP dan RP). Hasil: label versi untuk nama file dan nomor patch baru. */
    fun bumpManifests(files: Map<String, ByteArray>, modified: MutableMap<String, ByteArray>, minPatch: Int): Pair<String, Int> {
        val parsed = LinkedHashMap<String, JSONObject>()
        for ((n, b) in files) if (n.endsWith("manifest.json")) parsed[n] = JSONObject(String(b, Charsets.UTF_8))
        var rpUuid: String? = null
        var rpNew: JSONArray? = null
        for (j in parsed.values) {
            if (isResource(j)) {
                val h = j.getJSONObject("header")
                val v = h.optJSONArray("version")
                if (v != null && v.length() >= 3) {
                    rpUuid = h.getString("uuid")
                    rpNew = bump(v, minPatch)
                }
            }
        }
        var verLabel = ""
        var newPatch = 0
        for ((n, j) in parsed) {
            val h = j.getJSONObject("header")
            val hv = h.optJSONArray("version")
            if (hv != null && hv.length() >= 3) {
                val nv = bump(hv, minPatch)
                h.put("version", nv)
                if (!isResource(j) || verLabel.isEmpty()) {
                    verLabel = "${nv.getInt(0)}_${nv.getInt(1)}_${nv.getInt(2)}"
                    newPatch = nv.getInt(2)
                }
            }
            val mods = j.optJSONArray("modules")
            if (mods != null) {
                for (k in 0 until mods.length()) {
                    val m = mods.getJSONObject(k)
                    val mv = m.optJSONArray("version")
                    if (mv != null && mv.length() >= 3) m.put("version", bump(mv, minPatch))
                }
            }
            val deps = j.optJSONArray("dependencies")
            if (deps != null && rpUuid != null && rpNew != null) {
                for (k in 0 until deps.length()) {
                    val d = deps.getJSONObject(k)
                    if (d.optString("uuid") == rpUuid) d.put("version", rpNew)
                }
            }
            modified[n] = j.toString(2).toByteArray(Charsets.UTF_8)
        }
        return Pair(if (verLabel.isEmpty()) "baru" else verLabel, newPatch)
    }

    /** Tulis ulang zip add-on: berkas di `modified` diganti, yang `drop` dibuang, `extra` ditambahkan. */
    fun writeZip(
        ctx: Context, addon: Uri, modified: Map<String, ByteArray>,
        drop: (String) -> Boolean, extra: List<Pair<String, File>>
    ): File {
        val outFile = File(ctx.cacheDir, "lyricsplus_out.mcaddon")
        val input = ctx.contentResolver.openInputStream(addon) ?: throw IOException("Tidak bisa membuka file add-on")
        input.use { ins ->
            ZipInputStream(BufferedInputStream(ins)).use { zin ->
                ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile), 1 shl 16)).use { zout ->
                    zout.setLevel(1)
                    var e = zin.nextEntry
                    while (e != null) {
                        val name = e.name
                        if (!drop(name)) {
                            zout.putNextEntry(ZipEntry(name))
                            if (!e.isDirectory) {
                                val repl = modified[name]
                                if (repl != null) zout.write(repl) else zin.copyTo(zout)
                            }
                            zout.closeEntry()
                        }
                        e = zin.nextEntry
                    }
                    for ((name, f) in extra) {
                        zout.putNextEntry(ZipEntry(name))
                        FileInputStream(f).use { it.copyTo(zout) }
                        zout.closeEntry()
                    }
                }
            }
        }
        return outFile
    }

    // Patch kecil supaya lagu tambahan tampil dengan lirik huruf 3D (sama seperti mode Spotify).
    private const val DYN_ANCHOR = "function renderDynamic(player, p, elapsed) {"
    private const val BRANCH_ANCHOR = "else if (mode===\"actionbar\") {"
    private const val DYN_WRAPPER =
        "// [LyricsPlus Builder] lagu tambahan memakai lirik huruf 3D yang sama seperti mode Spotify\n" +
            "function renderDynLocal(player, p, elapsed) {\n" +
            "  if (!p.lsLocal) p.lsLocal = { id: p.song.id, duration: p.song.durationSeconds, dyn: prepareDynamic(p.lines.map(l => ({ t: l.time, text: l.text })), p.song.durationSeconds) };\n" +
            "  p.stream = p.lsLocal;\n" +
            "  try { renderDynamic(player, p, elapsed); } finally { p.stream = undefined; }\n" +
            "}\n"
    private const val BRANCH_NEW =
        "else if (mode===\"styled\" && p.lines && p.lines.length) {\n" +
            "          renderDynLocal(player,p,elapsed);\n" +
            "        } else if (mode===\"actionbar\") {"

    private fun patchMain(src: String, notes: MutableList<String>): String? {
        if (src.contains("renderDynLocal")) return null
        if (src.indexOf(DYN_ANCHOR) < 0 || src.indexOf(BRANCH_ANCHOR) < 0 ||
            src.indexOf(DYN_ANCHOR) != src.lastIndexOf(DYN_ANCHOR) ||
            src.indexOf(BRANCH_ANCHOR) != src.lastIndexOf(BRANCH_ANCHOR)
        ) {
            notes.add("Patch lirik 3D dilewati (versi main.js beda). Lagu tetap masuk, liriknya tampil sebagai teks biasa.")
            return null
        }
        return src.replace(DYN_ANCHOR, DYN_WRAPPER + DYN_ANCHOR).replace(BRANCH_ANCHOR, BRANCH_NEW)
    }

    /** Tambahkan satu atau beberapa lagu ke add-on. offsetSec = koreksi game, ditambahkan ke semua lirik. */
    fun build(ctx: Context, addon: Uri, songs: List<NewSong>, offsetSec: Double, minPatch: Int): Out {
        if (songs.isEmpty()) throw IOException("Tidak ada lagu untuk ditambahkan")
        val notes = ArrayList<String>()
        val files = readKey(ctx, addon)
        val songsName = files.keys.firstOrNull { it.endsWith("scripts/songs.js") }
            ?: throw IOException("Ini bukan add-on LyricsPlus (scripts/songs.js tidak ada)")
        val sdName = files.keys.firstOrNull { it.endsWith("sounds/sound_definitions.json") }
            ?: throw IOException("sounds/sound_definitions.json tidak ada di add-on")
        val mainName = files.keys.firstOrNull { it.endsWith("scripts/main.js") }
        val modified = HashMap<String, ByteArray>()

        var songsJs = String(files[songsName]!!, Charsets.UTF_8)
        val sd = JSONObject(String(files[sdName]!!, Charsets.UTF_8))
        val defs = sd.getJSONObject("sound_definitions")

        // Nomor lagu berikutnya
        var maxNo = 0
        val idRe = Regex("song_(\\d+)")
        Regex("id:\\s*\"song_(\\d+)\"").findAll(songsJs).forEach { maxNo = maxOf(maxNo, it.groupValues[1].toInt()) }
        val keys = defs.keys()
        while (keys.hasNext()) {
            val m = idRe.find(keys.next())
            if (m != null) maxNo = maxOf(maxNo, m.groupValues[1].toInt())
        }

        val end = songsJs.lastIndexOf("];")
        val lastBrace = if (end >= 0) songsJs.lastIndexOf('}', end) else -1
        if (end < 0 || lastBrace < 0) throw IOException("Format songs.js tidak dikenali")

        val prefix = sdName.removeSuffix("sounds/sound_definitions.json")
        val ids = ArrayList<String>()
        val extra = ArrayList<Pair<String, File>>()
        val insert = StringBuilder()
        for ((k, s) in songs.withIndex()) {
            val id = "song_%02d".format(maxNo + 1 + k)
            ids.add(id)
            var lrc = LrcShift.build(LrcShift.parse(s.lrc))
            if (lrc.isBlank()) throw IOException("Lirik \"${s.title}\" harus berformat LRC, contoh: [00:12.50] baris lirik")
            if (offsetSec != 0.0) lrc = LrcShift.shift(lrc, offsetSec)
            val title = s.title.ifBlank { "Lagu baru" }
            val artist = s.artist.ifBlank { "Belum diisi" }
            insert.append(",\n  {\n")
                .append("    id: ").append(q(id)).append(",\n")
                .append("    title: ").append(q(title)).append(",\n")
                .append("    artist: ").append(q(artist)).append(",\n")
                .append("    soundId: ").append(q("lyricsplus.$id")).append(",\n")
                .append("    durationSeconds: ").append(s.durationSec).append(",\n")
                .append("    lrc: ").append(q(lrc)).append("\n")
                .append("  }")

            val snd = JSONObject()
                .put("name", "sounds/music/$id")
                .put("volume", 1.0)
                .put("stream", true)
                .put("load_on_low_memory", true)
            defs.put("lyricsplus.$id", JSONObject().put("category", "music").put("sounds", JSONArray().put(snd)))
            extra.add(Pair(prefix + "sounds/music/$id.wav", s.wav))
        }
        songsJs = songsJs.substring(0, lastBrace + 1) + insert + songsJs.substring(lastBrace + 1)
        modified[songsName] = songsJs.toByteArray(Charsets.UTF_8)
        modified[sdName] = sd.toString(2).toByteArray(Charsets.UTF_8)

        if (mainName != null) {
            val patched = patchMain(String(files[mainName]!!, Charsets.UTF_8), notes)
            if (patched != null) modified[mainName] = patched.toByteArray(Charsets.UTF_8)
        }

        val (label, patch) = bumpManifests(files, modified, minPatch)
        val extraNames = extra.map { it.first }.toSet()
        val outFile = writeZip(ctx, addon, modified, { n -> extraNames.contains(n) }, extra)
        return Out(outFile, "LyricsPlus_$label.mcaddon", ids, notes, patch)
    }
}
