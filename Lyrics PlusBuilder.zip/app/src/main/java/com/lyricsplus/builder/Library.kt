package com.lyricsplus.builder

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import org.json.JSONTokener
import java.io.BufferedInputStream
import java.io.IOException
import java.util.zip.ZipInputStream

/** Daftar lagu di dalam add-on dan penghapusan lagu. */
object Library {
    class SongInfo(
        val id: String, val title: String, val artist: String,
        val duration: Int, val bytes: Long, val ext: String
    ) {
        /** Lagu tambahan dari APK ini berformat .wav. Lagu bawaan (.ogg) dilindungi supaya menu add-on tidak rusak. */
        val deletable: Boolean get() = ext == "wav"
    }

    /** Cari rentang tiap objek lagu di dalam array SONGS. Hasil: posisi '[' , posisi ']' , daftar rentang objek. */
    private fun scan(js: String): Triple<Int, Int, List<IntRange>> {
        val decl = js.indexOf("SONGS")
        if (decl < 0) throw IOException("Format songs.js tidak dikenali")
        val arrStart = js.indexOf('[', decl)
        if (arrStart < 0) throw IOException("Format songs.js tidak dikenali")
        val objs = ArrayList<IntRange>()
        var depth = 0
        var objStart = -1
        var arrEnd = -1
        var i = arrStart + 1
        while (i < js.length) {
            val c = js[i]
            if (c == '"' || c == '\'' || c == '`') {
                var j = i + 1
                while (j < js.length && js[j] != c) {
                    if (js[j] == '\\') j++
                    j++
                }
                i = j + 1
                continue
            }
            if (c == '/' && i + 1 < js.length && js[i + 1] == '/') {
                while (i < js.length && js[i] != '\n') i++
                continue
            }
            if (c == '{') {
                if (depth == 0) objStart = i
                depth++
            } else if (c == '}') {
                depth--
                if (depth == 0 && objStart >= 0) {
                    objs.add(objStart..i)
                    objStart = -1
                }
            } else if (c == ']' && depth == 0) {
                arrEnd = i
                break
            }
            i++
        }
        if (arrEnd < 0) throw IOException("Format songs.js tidak dikenali")
        return Triple(arrStart, arrEnd, objs)
    }

    private fun str(obj: String, key: String): String {
        val m = Regex("\\b" + key + ":\\s*\"((?:\\\\.|[^\"\\\\])*)\"").find(obj) ?: return ""
        return try {
            JSONTokener("\"" + m.groupValues[1] + "\"").nextValue() as String
        } catch (e: Exception) {
            m.groupValues[1]
        }
    }

    fun list(ctx: Context, addon: Uri): List<SongInfo> {
        val files = AddonBuilder.readKey(ctx, addon)
        val songsName = files.keys.firstOrNull { it.endsWith("scripts/songs.js") }
            ?: throw IOException("Ini bukan add-on LyricsPlus (scripts/songs.js tidak ada)")
        val js = String(files[songsName]!!, Charsets.UTF_8)
        val (_, _, objs) = scan(js)

        val sizes = HashMap<String, Long>()
        val exts = HashMap<String, String>()
        val soundRe = Regex("sounds/music/(song_\\d+)\\.(\\w+)\$")
        val input = ctx.contentResolver.openInputStream(addon) ?: throw IOException("Tidak bisa membuka file add-on")
        input.use { ins ->
            ZipInputStream(BufferedInputStream(ins)).use { zin ->
                val buf = ByteArray(65536)
                var e = zin.nextEntry
                while (e != null) {
                    val m = soundRe.find(e.name)
                    if (m != null) {
                        var total = 0L
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            total += n
                        }
                        sizes[m.groupValues[1]] = total
                        exts[m.groupValues[1]] = m.groupValues[2].lowercase()
                    }
                    e = zin.nextEntry
                }
            }
        }

        val out = ArrayList<SongInfo>()
        for (r in objs) {
            val txt = js.substring(r.first, r.last + 1)
            val id = str(txt, "id")
            if (id.isEmpty()) continue
            val dur = Regex("durationSeconds:\\s*(\\d+)").find(txt)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            out.add(SongInfo(id, str(txt, "title"), str(txt, "artist"), dur, sizes[id] ?: 0L, exts[id] ?: ""))
        }
        return out
    }

    /** Hapus lagu (songs.js, sound_definitions.json, dan file audio) lalu tulis add-on baru. */
    fun delete(ctx: Context, addon: Uri, ids: Set<String>, minPatch: Int): AddonBuilder.Out {
        val files = AddonBuilder.readKey(ctx, addon)
        val songsName = files.keys.firstOrNull { it.endsWith("scripts/songs.js") }
            ?: throw IOException("Ini bukan add-on LyricsPlus (scripts/songs.js tidak ada)")
        val sdName = files.keys.firstOrNull { it.endsWith("sounds/sound_definitions.json") }
            ?: throw IOException("sounds/sound_definitions.json tidak ada di add-on")
        val modified = HashMap<String, ByteArray>()

        val js = String(files[songsName]!!, Charsets.UTF_8)
        val (a, b, objs) = scan(js)
        val kept = ArrayList<String>()
        for (r in objs) {
            val txt = js.substring(r.first, r.last + 1)
            if (!ids.contains(str(txt, "id"))) kept.add(txt)
        }
        val arrText = if (kept.isEmpty()) "[]" else "[\n  " + kept.joinToString(",\n  ") + "\n]"
        modified[songsName] = (js.substring(0, a) + arrText + js.substring(b + 1)).toByteArray(Charsets.UTF_8)

        val sd = JSONObject(String(files[sdName]!!, Charsets.UTF_8))
        val defs = sd.getJSONObject("sound_definitions")
        val remove = ArrayList<String>()
        val keys = defs.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (ids.any { k.endsWith(it) }) remove.add(k)
        }
        for (k in remove) defs.remove(k)
        modified[sdName] = sd.toString(2).toByteArray(Charsets.UTF_8)

        val (label, patch) = AddonBuilder.bumpManifests(files, modified, minPatch)
        val patterns = ids.map { Regex("sounds/music/" + it + "\\.") }
        val file = AddonBuilder.writeZip(ctx, addon, modified, { n -> patterns.any { it.containsMatchIn(n) } }, emptyList())
        return AddonBuilder.Out(file, "LyricsPlus_$label.mcaddon", ids.toList(), emptyList(), patch)
    }
}
